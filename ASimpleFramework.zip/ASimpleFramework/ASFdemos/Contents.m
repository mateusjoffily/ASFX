% A Simple Framework (ASF)
% Version 1.0           19 October 2009
% 
% ASF Demos
% 
% ASF_demo1             - simple priming experiment
% ASF_demo1a            - same as ASF_demo1, but with skipping sync tests
% ASF_demo1b            - same as ASF_demo1a, but changing screen resolution
% ASF_demo1c            - same as ASF_demo1b, but with final timing test


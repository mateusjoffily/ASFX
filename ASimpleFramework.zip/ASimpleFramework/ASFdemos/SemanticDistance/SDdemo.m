Cfg.userSuppliedTrialFunction = @ASFShowTrial_TextAndSound;
Cfg.readTextStimuli = 'SD_Text.txt';
Cfg.readSoundStimuli = 'SD_Sound.txt';
Cfg.userDefinedSTMcolumns = 10;
%Cfg.Screen.rect = [1, 1, 640, 480];
Cfg.Screen.skipSyncTests = 1;
ExpInfo = ASF('SD.std', 'SD.trd', 'junk', Cfg)
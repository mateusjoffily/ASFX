%ASF_demo2_1 demonstrates a simple masked priming experiment
%[ExpInfo] = ASF('Demo2.std', 'Demo2_1.trd', 'testsubject', []); %FROM ASF's DEMO DIRECTORY
[ExpInfo] = ASF('Demo2.std', 'Demo2_2.trd', 'testsubject', []); %FROM ASF's DEMO DIRECTORY

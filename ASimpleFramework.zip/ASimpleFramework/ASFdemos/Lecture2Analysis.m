function re = Demo2Analysis(nameOfResultFile)
%function Demo2Analysis(nameOfResultFile)
%%EXAMPLE CALL:
%Demo2Analysis('SUB02')

%LOAD DATA
load(nameOfResultFile)

%CONVERT ASF's LOGFILE INTO A MATRIX WITH THE FOLLOWING FORMAT
% ROW -> trial
% COL 1: CODE
% COL 2: RT
% COL 3: KEY
%COL 4: CORRECTRESPONSE

%see: help ASF_readExpInfo
re = ASF_readExpInfo(expinfo);
code = ASF_decode(re, fliplr(expinfo.factorinfo));
%THIS IS KNOWLEDGE FROM THE DESIGNER OF THE EXPERIMENT
%1: prime left, target left   ->CONGRUENT
%2: prime left, target right  ->INCONGRUENT
%3: prime right, target left  ->INCONGRUENT
%4: prime right, target right ->CONGRUENT

%FIND ROW NUMBER IN RESULT MATRIX CORRESPONDING TO CONGRUENT TRIALS
congruency = code(:, 3);
congruencyLevels = unique(congruency);
nCongruencyLevels = length(congruencyLevels);

soa = code(:, 1);
soaLevels = unique(soa);
nSOA = length(soaLevels);

%FIND ROW NUMBER IN RESULT MATRIX CORRESPONDING TO INCONGRUENT TRIALS
%casesInongruent = find( (re(:, 1) == 2)|(re(:, 1) == 3));

for iSOA = 1:nSOA
    for iCongruency = 1:nCongruencyLevels
        %CALCULATE THE MEAN FOR CONGRUENT AND INCONGRUENT TRIALS
        %PUT RESULT FOR CONGRUENT IN FIRST COLUMN, FOR INCONGRUENT IN SECOND COLUMN
        cases = find( (soa == soaLevels(iSOA)) & (congruency == congruencyLevels(iCongruency) ));
        m(iCongruency, iSOA) = mean(re(cases, 2));
        s(iCongruency, iSOA) = std(re(cases, 2));
    end
end

%CREATE A FIGURE WINDOW FOR GRAPHICS
figure
%PLOT REULTS
errorbar(m, s)
%PROVIDE LABELS AND TICKMARKS
set(gca, 'xtick', [1, 2, 3], 'xticklabel', {'congruent', 'neutral', 'incongruent'})
xlabel('Congruency')
ylabel('RT [ms]')

% ASF_demo1c demonstrates a simple masked priming experiment with:
%      skipping SyncTest
%      change of screen resolution
%      timing diagnosis at the end of the experiment
% Example call:
% ExpInfo = ASF_demo1c
function ExpInfo = ASF_demo1c
%[ExpInfo] = ASF('Demo1.std', 'Demo1.trd', 'testsubject', []); %FROM ASF's DEMO DIRECTORY
Cfg.Screen.skipSyncTests = 1;
Cfg.Screen.Resolution.width = 1024;
Cfg.Screen.Resolution.height = 768;
Cfg.enableTimingDiagnosis = 1;

[ExpInfo] = ASF('Demo1.std', 'Demo1.trd', 'testsubject', Cfg); %FROM ASF's DEMO DIRECTORY

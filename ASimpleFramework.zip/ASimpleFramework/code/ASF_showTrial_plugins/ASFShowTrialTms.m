%% ShowTrial (SHOWTRIAL WITH MOUSE, SERIAL OR PARALLEL RESPONSE BOX AS RESPONSE DEVICE)
function trialinfo = ASFShowTrialTMS(atrial, windowPtr, Stimuli, Cfg)
%SAVE TIME BY ALLOCATING ALL VARIABLES UPFRONT

    % VBLTimestamp system time (in seconds) when the actual flip has happened in the return argument
    % StimulusOnsetTime An estimate of Stimulus-onset time
    % FlipTimestamp is a timestamp taken at the end of Flip's execution
    % Use the difference between FlipTimestamp and VBLTimestamp to get an estimate of how long Flips execution takes.
    % Missed indicates if the requested presentation deadline for your stimulus has been missed. A negative
    % value means that dead- lines have been satisfied. Positive values indicate a deadline-miss.
    % Beampos is the position of the monitor scanning beam when the time measurement was taken (useful for correctness tests)
VBLTimestamp = 0; StimulusOnsetTime = 0; FlipTimestamp = 0; Missed = 0; Beampos = 0;

startRTMeasurement = 0; endRTMeasurement = 0;
timing = [0, VBLTimestamp, StimulusOnsetTime, FlipTimestamp, Missed, Beampos];
nPages = length(atrial.pageNumber);
timing(nPages, end) = 0;
this_response = [];

tolerance = 1/400;
responseGiven = 0;
this_response.key = [];
this_response.RT = [];

%IF YOU WANT TO DO ANY OFFLINE STIMULUS RENDERING (I.E. BEFORE THE TRIAL STARTS), PUT THAT CODE HERE


%LOG DATE AND TIME OF TRIAL
strDate = datestr(now); %store when trial was presented

%IF EXTERNAL TIMING REQUESTED (e.g. fMRI JITTERING)
if Cfg.useTrialOnsetTimes
    while((GetSecs- Cfg.experimentStart) < atrial.tOnset)
    end
end
%LOG TIME OF TRIAL ONSET WITH RESPECT TO START OF THE EXPERIMENT
%USEFUL FOR DATA ANALYSIS IN fMRI
tStart = GetSecs - Cfg.experimentStart;


triggerPage = atrial.userDefined(1); %TRD FILE NEEDS ONE EXTRA COLUMN


%CYCLE THROUGH PAGES FOR THIS TRIAL
for i = 1:atrial.startRTonPage-1

    %PUT THE APPROPRIATE TEXTURE ON THE BACK BUFFER
    Screen('DrawTexture', windowPtr, Stimuli.tex(atrial.pageNumber(i)));

    %PRESERVE BACK BUFFER IF THIS TEXTURE S TO BE SHOW AGAIN AT THE NEXT FLIP
    bPreserveBackBuffer = atrial.pageDuration(i) > 1;

    %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
    %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
    [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = ASF_xFlip(windowPtr, Stimuli.tex(atrial.pageNumber(i)), Cfg, bPreserveBackBuffer);

    %SET TRIGGER?
    if i == triggerPage
        ASF_setTrigger(Cfg, 1); %TAKES ABOUT 1.5ms
        ASF_setTrigger(Cfg, 0); %TAKES ABOUT 1.5ms
    end

    
    
    %LOG WHEN THIS PAGE APPEARED
    timing(i, 1:6) = [atrial.pageDuration(i), VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos];

    
    %WAIT OUT STIMULUS DURATION IN FRAMES. WE USE PAGE FLIPPING RATHER THAN
    %A TIMER WHENEVER POSSIBLE BECAUSE GRAPHICS BOARDS PROVIDE EXCELLENT
    %TIMING; THIS IS THE REASON WHY WE MAY WANT TO KEEP A STIMULUS IN THE
    %BACKBUFFER (NONDESTRUCTIVE PAGE FLIPPING)
    %NOT ALL GRAPHICS CARDS CAN DO THIS. FOR CARDS WITHOUT AUXILIARY
    %BACKBUFFERS WE COPY THE TEXTURE EXPLICITLY ON THE BACKBUFFER AFTER IT
    %HAS BEEN DESTROYED BY FLIPPING
    nFlips = atrial.pageDuration(i) - 1; %WE ALREADY FLIPPED ONCE
    for FlipNumber = 1:nFlips
        %PRESERVE BACK BUFFER IF THIS TEXTURE IS TO BE SHOW AGAIN AT THE NEXT FLIP
        bPreserveBackBuffer = FlipNumber < nFlips;

        %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
        %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
        ASF_xFlip(windowPtr, Stimuli.tex(atrial.pageNumber(i)), Cfg, bPreserveBackBuffer);
    end
end

%SPECIAL TREATMENT FOR THE DISPLAY PAGE ON WHICH WE ALLOW REACTIONS
%RT PAGE
for i = atrial.startRTonPage:atrial.startRTonPage
    %PUT THE APPROPRIATE TEXTURE ON THE BACK BUFFER
    Screen('DrawTexture', windowPtr, Stimuli.tex(atrial.pageNumber(i)));

    %DO NOT PUT THIS PAGE AGAIN ON THE BACKBUFFER, WE WILL WAIT IT OUT
    %USING THE TIMER NOT FLIPPING
    bPreserveBackBuffer = 0;

    %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
    %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
    [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = ASF_xFlip(windowPtr, Stimuli.tex(atrial.pageNumber(i)), Cfg, bPreserveBackBuffer);

    %SET TRIGGER?
    if i == triggerPage
        ASF_setTrigger(Cfg, 1); %TAKES ABOUT 1.5ms
        ASF_setTrigger(Cfg, 0); %TAKES ABOUT 1.5ms
    end

    startRTMeasurement = VBLTimestamp;

    %STORE TIME OF PAGE FLIPPING FOR DIAGNOSTIC PURPOSES
    timing(i, 1:6) = [atrial.pageDuration(i), VBLTimestamp, StimulusOnsetTime, FlipTimestamp, Missed, Beampos];

    pageDuration_in_sec = atrial.pageDuration(i)*Cfg.Screen.monitorFlipInterval;
    [x, y, buttons, t0, t1] = ASF_waitForResponse(Cfg, pageDuration_in_sec - tolerance);
    if any(buttons)
        responseGiven = 1;
        %a button has been pressed before timeout
        if Cfg.responseTerminatesTrial
            Snd('Play','Quack')
        else
            WaitSecs(pageDuration_in_sec - (t1 - startRTMeasurement) -tolerance) %wait out the remainder of the stimulus duration 5ms margin
        end
        this_response.key = find(buttons); %find which button it was
        this_response.RT = (t1 - startRTMeasurement)*1000; %compute response time
    end
end

%OTHER PICS
for i = atrial.startRTonPage+1:nPages
    %PUT THE APPROPRIATE TEXTURE ON THE BACK BUFFER
    Screen('DrawTexture', windowPtr, Stimuli.tex(atrial.pageNumber(i)));

    %PRESERVE BACK BUFFER IF THIS TEXTURE IS TO BE SHOW AGAIN AT THE NEXT FLIP
    bPreserveBackBuffer = atrial.pageDuration(i) > 1;

    %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
    %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
    [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = ASF_xFlip(windowPtr, Stimuli.tex(atrial.pageNumber(i)), Cfg, bPreserveBackBuffer);
    
    %SET TRIGGER?
    if i == triggerPage
        ASF_setTrigger(Cfg, 1); %TAKES ABOUT 1.5ms
        ASF_setTrigger(Cfg, 0); %TAKES ABOUT 1.5ms
    end


    %STORE TIME OF PAGE FLIPPING FOR DIAGNOSTIC PURPOSES
    timing(i, 1:6) = [atrial.pageDuration(i), VBLTimestamp, StimulusOnsetTime, FlipTimestamp, Missed, Beampos];
    
    if(responseGiven)
        %IF THE RESPONSE HAS ALREADY BEEN GIVEN


        %WAIT OUT STIMULUS DURATION IN FRAMES
        nFlips = atrial.pageDuration(i) - 1; %WE ALREADY FLIPPED ONCE
        for FlipNumber = 1:nFlips
            %PRESERVE BACK BUFFER IF THIS TEXTURE IS TO BE SHOW AGAIN AT THE NEXT FLIP
            bPreserveBackBuffer = FlipNumber < nFlips;

            %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
            %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
            ASF_xFlip(windowPtr, Stimuli.tex(atrial.pageNumber(i)), Cfg, bPreserveBackBuffer);
        end
    else
        %THE RESPONSE HAS NOT YET BEEN GIVEN
        pageDuration_in_sec = atrial.pageDuration(i)*Cfg.Screen.monitorFlipInterval;
        [x, y, buttons, t0, t1] = ASF_waitForResponse(Cfg, pageDuration_in_sec - tolerance);
        
        if any(buttons)
            responseGiven = 1;
            %a button has been pressed before timeout
            if Cfg.responseTerminatesTrial
                Snd('Play','Quack')
            else
                %THIS IS DIFFERENT WITH RESPECT TO THE RT PAGE FOR THE
                %PAGES FOLLOWING THE RTPAGE
                WaitSecs(pageDuration_in_sec - (t1-t0) -tolerance) %wait out the remainder of the stimulus duration 5ms margin
            end
            this_response.key = find(buttons); %find which button it was
            this_response.RT = (t1 - startRTMeasurement)*1000; %compute response time
        end

    end
end

%IF YOU WANT TO FORCE A RESPONSE
if Cfg.waitUntilResponseAfterTrial && ~responseGiven
    %[x, y, buttons, t0, t1] = WaitForMousePress(10);
    [x, y, buttons, t0, t1] = ASF_waitForResponse(Cfg, 10);

    if any(buttons)
        responseGiven = 1; %#ok<NASGU>
        %a button has been pressed before timeout
        this_response.key = find(buttons); %find which button it was
        this_response.RT = (t1 - startRTMeasurement)*1000; %compute response time
    end
end

%TRIAL BY TRIAL FEEDBACK
if Cfg.feedbackTrialCorrect || Cfg.feedbackTrialError
    %EVALUATE RESPONSE
    if this_response.key == atrial.correctResponse
        %CORRECT RESPONSE
        if Cfg.feedbackTrialCorrect
            Snd('Play', Cfg.sndOK)
            Snd('Wait');
        end
    else
        %WRONG RESPONSE
        if Cfg.feedbackTrialError
            Snd('Play', Cfg.sndERR)
            Snd('Wait');
        end
    end
end

%PACK INFORMATION ABOUT THIS TRIAL INTO STRUCTURE trialinfo (THE RETURN ARGUMENT)
%PLEASE MAKE SURE THAT trialinfo CONTAINS THE FIELDS:
%   trial
%   datestr
%   tStart
%   Response
%   timing
%   startRTMeasurement
%   endRTMeasurement
%OTHERWISE DIAGNOSTIC PROCEDURES OR ROUTINES FOR DATAANALYSIS MAIGHT FAIL
trialinfo.trial = atrial;  %store page numbers and durations
trialinfo.datestr = strDate;
trialinfo.tStart = tStart;
trialinfo.Response = this_response;
trialinfo.timing = timing;
trialinfo.startRTMeasurement = startRTMeasurement;
trialinfo.endRTMeasurement = endRTMeasurement;
%% ShowTrial (SHOWTRIAL WITH MOUSE, SERIAL OR PARALLEL RESPONSE BOX AS RESPONSE DEVICE)
function TrialInfo = ASF_ShowTrialTriggerTest(atrial, windowPtr, Stimuli, Cfg)
%SAVE TIME BY ALLOCATING ALL VARIABLES UPFRONT

    % VBLTimestamp system time (in seconds) when the actual flip has happened in the return argument
    % StimulusOnsetTime An estimate of Stimulus-onset time
    % FlipTimestamp is a timestamp taken at the end of Flip's execution
    % Use the difference between FlipTimestamp and VBLTimestamp to get an estimate of how long Flips execution takes.
    % Missed indicates if the requested presentation deadline for your stimulus has been missed. A negative
    % value means that dead- lines have been satisfied. Positive values indicate a deadline-miss.
    % Beampos is the position of the monitor scanning beam when the time measurement was taken (useful for correctness tests)
VBLTimestamp = 0; StimulusOnsetTime = 0; FlipTimestamp = 0; Missed = 0; Beampos = 0;

StartRTMeasurement = 0; EndRTMeasurement = 0;
timing = [0, VBLTimestamp, StimulusOnsetTime, FlipTimestamp, Missed, Beampos];
nPages = length(atrial.pageNumber);
timing(nPages, end) = 0;
this_response = [];

tolerance = Cfg.Screen.monitorFlipInterval*0.75; %WAS 1/400 BUT THIS SEEMED TO PRODUCE TOO MANY TIMING ERRORS ON PAGES WITH RESPONSE COLLECTION
                    %HOWEVER, THIS MUST NOT BE LONGER THAN ONE FRAME
                    %DURATION. EXPERIMENTING WITH ONE QUARTER OF A FRAME

responseGiven = 0;
this_response.key = [];
this_response.RT = [];

%IF YOU WANT TO DO ANY OFFLINE STIMULUS RENDERING (I.E. BEFORE THE TRIAL STARTS), PUT THAT CODE HERE

%--------------------------------------------------------------------------
%TRIAL PRESENTATION HAS SEVERAL PHASES
% 1) WAIT FOR THE RIGHT TIME TO START TRIAL PRESENTATION. THIS MAY BE IMMEDIATELY OR USER DEFINED (E.G. IN fMRI EXPERIMENTS)
%
% 2) LOOP THROUGH PAGE PRESENTATIONS WITHOUT RESPONSE COLLECTION
%
% 3) LOOP THROUGH PAGE PRESENTATIONS WHILE CHECKING FOR USER INPUT/RESPONSES
%
% 4) LOOP THROUGH PAGE PRESENTATIONS WITHOUT RESPONSE COLLECTION (AFTER RESPONSE HAS BEEN GIVEN)
%
% 5) FEEDBACK
%--------------------------------------------------------------------------

%LOG DATE AND TIME OF TRIAL
strDate = datestr(now); %store when trial was presented

%RUN THE FUNCTION ASF_waitForScannerSynch once with a short timeout to
%make sure that it is stored in memory, this will increase timing
%accuracy
fprintf(1, 'LOADING ASF_waitForScannerSynch into memory ...');
CfgTmp = Cfg;
CfgTmp.ScannerSynchShowDefaultMessage = 0;
CfgTmp.scannerSynchTimeOutMs = 100;
ASF_waitForScannerSynch(windowPtr, CfgTmp)
fprintf(1, ' DONE.\n');


%--------------------------------------------------------------------------
% PHASE 1) WAIT FOR THE RIGHT TIME TO START TRIAL PRESENTATION. THIS MAY BE IMMEDIATELY OR USER DEFINED (E.G. IN fMRI EXPERIMENTS)
%--------------------------------------------------------------------------
%IF EXTERNAL TIMING REQUESTED (e.g. fMRI JITTERING)
if Cfg.useTrialOnsetTimes
    while((GetSecs- Cfg.experimentStart) < atrial.tOnset)
    end
end
%--------------------------------------------------------------------------
%END OF PHASE 1
%--------------------------------------------------------------------------


%LOG TIME OF TRIAL ONSET WITH RESPECT TO START OF THE EXPERIMENT
%USEFUL FOR DATA ANALYSIS IN fMRI
tStart = GetSecs - Cfg.experimentStart;

iVol = 0;
Cfg.ScannerSynchShowDefaultMessage = 0;

%PREALLOCATE STORAGE SPACE FOR RESULTS
tSynch(Cfg.TriggerTestNumberOfTriggers) = 0;
timing = repmat(timing, [Cfg.TriggerTestNumberOfTriggers, 1]);

for iVol = 1:Cfg.TriggerTestNumberOfTriggers
    %RENDER TEXT ON BACK BUFFER

        ASF_waitForScannerSynch(windowPtr, Cfg);
        timeOfSynch = GetSecs;
        
        if iVol == 1
            tStart = timeOfSynch;
            tExp = 0;
            tSynch(1) = 0;
        else
            tSynch(iVol) = timeOfSynch - tStart;
            tExp = tSynch(iVol) - tSynch(iVol - 1);
        end

        [nx, ny, bbox] = DrawFormattedText(windowPtr, sprintf('T: %8.3f, VOL %04d, EXP: %8.3f', tSynch(iVol), iVol, tExp), 'center', 'center', 0);
        [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = Screen('Flip', windowPtr);
        timing(iVol, 2) = VBLTimestamp;
        ASF_checkforuserabort(windowPtr, Cfg);
end
this_response.key = 0;
this_response.RT = tSynch;
StartRTMeasurement = 0;        
EndRTMeasurement = 0;

%PACK INFORMATION ABOUT THIS TRIAL INTO STRUCTURE TrialInfo (THE RETURN ARGUMENT)
%PLEASE MAKE SURE THAT TrialInfo CONTAINS THE FIELDS:
%   trial
%   datestr
%   tStart
%   Response
%   timing
%   StartRTMeasurement
%   EndRTMeasurement
%OTHERWISE DIAGNOSTIC PROCEDURES OR ROUTINES FOR DATAANALYSIS MAIGHT FAIL
TrialInfo.trial = atrial;  %store page numbers and durations
TrialInfo.datestr = strDate;
TrialInfo.tStart = tStart;
TrialInfo.Response = this_response;
TrialInfo.timing = timing;
TrialInfo.startRTMeasurement = StartRTMeasurement;
TrialInfo.endRTMeasurement = EndRTMeasurement;
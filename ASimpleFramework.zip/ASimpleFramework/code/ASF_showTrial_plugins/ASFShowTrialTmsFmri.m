function TrialInfo = ASFShowTrialTmsFmri(atrial, windowPtr, Stimuli, Cfg)
%function TrialInfo = ASFShowTrialTmsFmri(atrial, windowPtr, Stimuli, Cfg)
%SAVE TIME BY ALLOCATING ALL VARIABLES UPFRONT

% VBLTimestamp system time (in seconds) when the actual flip has happened in the return argument
% StimulusOnsetTime An estimate of Stimulus-onset time
% FlipTimestamp is a timestamp taken at the end of Flip's execution
% Use the difference between FlipTimestamp and VBLTimestamp to get an estimate of how long Flips execution takes.
% Missed indicates if the requested presentation deadline for your stimulus has been missed. A negative
% value means that dead- lines have been satisfied. Positive values indicate a deadline-miss.
% Beampos is the position of the monitor scanning beam when the time measurement was taken (useful for correctness tests)
VBLTimestamp = 0; StimulusOnsetTime = 0; FlipTimestamp = 0; Missed = 0; Beampos = 0;

timing = [0, VBLTimestamp, StimulusOnsetTime, FlipTimestamp, Missed, Beampos];
npages = length(atrial.pageNumber);
timing(npages, end) = 0;

%IF YOU WANT TO DO ANY OFFLINE STIMULUS RENDERING (I.E. BEFORE THE TRIAL STARTS), PUT THAT CODE HERE

Screen('BlendFunction', windowPtr, GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

%LOG DATE AND TIME OF TRIAL
strDate = datestr(now); %store when trial was presented



Cfg.Exp.blockDurationVols = 10;
Cfg.Exp.delayScannerTmsMillisec = 2500;

%
%
%
% %IF EXTERNAL TIMING REQUESTED (e.g. fMRI JITTERING)
% if Cfg.useTrialOnsetTimes
%     while((GetSecs- Cfg.experimentStart) < atrial.tOnset)
%     end
% end
%LOG TIME OF TRIAL ONSET WITH RESPECT TO START OF THE EXPERIMENT


putvalue(Cfg.hardware.parallel.mydio.TriggerPort, 1) %DOWN

% %USEFUL FOR DATA ANALYSIS IN fMRI
% tStart = GetSecs;% - Cfg.experimentStart;
% tLast = tStart;


iVol = 0;
for nBlocks = 1:10
    %BLOCK A: WAIT FOR SCANNER DO NOTHING
    for i= 1:Cfg.Exp.blockDurationVols
        ASFWaitForScannerSynch(windowPtr, Cfg);
        iVol = iVol + 1;
        if iVol == 1
            tStart = GetSecs;
        end
        fprintf('VOL %03d, NO TRIGGER OUTPUT\n', iVol)
        checkforuserabort(windowPtr, Cfg);
    end

    %BLOCK B: WAIT FOR SCANNER, AFTER A DELAY X TRIGGER TMS
    for i= 1:Cfg.Exp.blockDurationVols
        %WAIT FOR SCANNER
        ASFWaitForScannerSynch(windowPtr, Cfg);

        %DELAY
        WaitSecs(Cfg.Exp.delayScannerTmsMillisec/1000)

%         %TRIGGER ON, DELAY, TRIGGER OFF
%         putvalue(Cfg.hardware.parallel.mydio.TriggerPort, 0) %UP
%         WaitSecs(0.1)
%         putvalue(Cfg.hardware.parallel.mydio.TriggerPort, 1) %DOWN


        %THETA PRT
        for j = 1:5
            %TRIGGER ON, DELAY, TRIGGER OFF
            putvalue(Cfg.hardware.parallel.mydio.TriggerPort, 0) %UP
            WaitSecs(0.001)
            putvalue(Cfg.hardware.parallel.mydio.TriggerPort, 1) %DOWN
            WaitSecs(0.020)
        end
        
        
        %Cfg.UseBackBuffer = 1;%useBackBuffer;
        %[ VBLTimestamp, StimulusOnsetTime, FlipTimestamp, Missed, Beampos ] = ASF_xFlip(windowPtr, [], Cfg, 0);

        %GetSecs
        
        fprintf('VOL %03d, DELAYED TRIGGER OUTPUT\n', iVol)
        
        checkforuserabort(windowPtr, Cfg);
    end
end



TrialInfo.trial = NaN;
TrialInfo.datestr = strDate;
TrialInfo.tStart = NaN;
TrialInfo.Response.key = NaN;
TrialInfo.Response.RT = NaN;
TrialInfo.timing = NaN;
TrialInfo.startRTMeasurement = NaN;
TrialInfo.endRTMeasurement = NaN;
%PACK INFORMATION ABOUT THIS TRIAL INTO STRUCTURE TrialInfo (THE RETURN ARGUMENT)
%PLEASE MAKE SURE THAT TrialInfo CONTAINS THE FIELDS:
%   trial
%   datestr
%   tStart
%   Response
%   timing
%   startRTMeasurement
%   endRTMeasurement
%OTHERWISE DIAGNOSTIC PROCEDURES OR ROUTINES FOR DATAANALYSIS MAIGHT FAIL
% TrialInfo.trial = atrial;  %store page numbers and durations
% TrialInfo.datestr = strDate;
% TrialInfo.tStart = tStart;
% TrialInfo.Response = this_response;
% TrialInfo.timing = timing;
% TrialInfo.startRTMeasurement = startRTMeasurement;
% TrialInfo.endRTMeasurement = endRTMeasurement;


return

%CYCLE THROUGH PAGES FOR THIS TRIAL
for i = 1:atrial.StartRTonPage-1

    %PUT THE APPROPRIATE TEXTURE ON THE BACK BUFFER
    Screen('DrawTexture', windowPtr, Stimuli.tex(atrial.pageNumber(i)));

    %PRESERVE BACK BUFFER IF THIS TEXTURE S TO BE SHOW AGAIN AT THE NEXT FLIP
    bPreserveBackBuffer = atrial.pageDuration(i) > 1;

    %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
    %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
    [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = ASF_xFlip(windowPtr, Stimuli.tex(atrial.pageNumber(i)), Cfg, bPreserveBackBuffer);

    %SET TRIGGER
    %     setTrigger(Cfg, atrial.pageNumber(i));
    ASF_setTrigger(Cfg, atrial.pageNumber(i));



    %LOG WHEN THIS PAGE APPEARED
    timing(i, 1:6) = [atrial.pageDuration(i), VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos];


    %WAIT OUT STIMULUS DURATION IN FRAMES. WE USE PAGE FLIPPING RATHER THAN
    %A TIMER WHENEVER POSSIBLE BECAUSE GRAPHICS BOARDS PROVIDE EXCELLENT
    %TIMING; THIS IS THE REASON WHY WE MAY WANT TO KEEP A STIMULUS IN THE
    %BACKBUFFER (NONDESTRUCTIVE PAGE FLIPPING)
    %NOT ALL GRAPHICS CARDS CAN DO THIS. FOR CARDS WITHOUT AUXILIARY
    %BACKBUFFERS WE COPY THE TEXTURE EXPLICITLY ON THE BACKBUFFER AFTER IT
    %HAS BEEN DESTROYED BY FLIPPING
    nFlips = atrial.pageDuration(i) - 1; %WE ALREADY FLIPPED ONCE
    for FlipNumber = 1:nFlips
        %PRESERVE BACK BUFFER IF THIS TEXTURE IS TO BE SHOW AGAIN AT THE NEXT FLIP
        bPreserveBackBuffer = FlipNumber < nFlips;

        %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
        %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
        ASF_xFlip(windowPtr, Stimuli.tex(atrial.pageNumber(i)), Cfg, bPreserveBackBuffer);

    end
end

%SPECIAL TREATMENT FOR THE DISPLAY PAGE ON WHICH WE ALLOW REACTIONS
%RT PAGE
for i = atrial.StartRTonPage:atrial.StartRTonPage
    %PUT THE APPROPRIATE TEXTURE ON THE BACK BUFFER
    Screen('DrawTexture', windowPtr, Stimuli.tex(atrial.pageNumber(i)));

    %DO NOT PUT THIS PAGE AGAIN ON THE BACKBUFFER, WE WILL WAIT IT OUT
    %USING THE TIMER NOT FLIPPING
    bPreserveBackBuffer = 0;

    %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
    %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
    [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = ASF_xFlip(windowPtr, Stimuli.tex(atrial.pageNumber(i)), Cfg, bPreserveBackBuffer);

    %SET TRIGGER
    setTrigger(Cfg, atrial.pageNumber(i));

    startRTMeasurement = VBLTimestamp;

    %STORE TIME OF PAGE FLIPPING FOR DIAGNOSTIC PURPOSES
    timing(i, 1:6) = [atrial.pageDuration(i), VBLTimestamp, StimulusOnsetTime, FlipTimestamp, Missed, Beampos];

    pageDuration_in_sec = atrial.pageDuration(i)*Cfg.Screen.monitorFlipInterval;
    [x, y, buttons, t0, t1] = ASF_waitForResponse(Cfg, pageDuration_in_sec - tolerance);
    if any(buttons)
        responseGiven = 1;
        %a button has been pressed before timeout
        if Cfg.ResponseTerminatesTrial
            Snd('Play','Quack')
        else
            WaitSecs(pageDuration_in_sec - (t1 - startRTMeasurement) -tolerance) %wait out the remainder of the stimulus duration 5ms margin
        end
        this_response.key = find(buttons); %find which button it was
        this_response.RT = (t1 - startRTMeasurement)*1000; %compute response time
    end
end

%OTHER PICS
for i = atrial.StartRTonPage+1:npages
    %PUT THE APPROPRIATE TEXTURE ON THE BACK BUFFER
    Screen('DrawTexture', windowPtr, Stimuli.tex(atrial.pageNumber(i)));

    %PRESERVE BACK BUFFER IF THIS TEXTURE IS TO BE SHOW AGAIN AT THE NEXT FLIP
    bPreserveBackBuffer = atrial.pageDuration(i) > 1;

    %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
    %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
    [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = ASF_xFlip(windowPtr, Stimuli.tex(atrial.pageNumber(i)), Cfg, bPreserveBackBuffer);

    %SET TRIGGER
    setTrigger(Cfg, atrial.pageNumber(i));

    %STORE TIME OF PAGE FLIPPING FOR DIAGNOSTIC PURPOSES
    timing(i, 1:6) = [atrial.pageDuration(i), VBLTimestamp, StimulusOnsetTime, FlipTimestamp, Missed, Beampos];

    if(responseGiven)
        %IF THE RESPONSE HAS ALREADY BEEN GIVEN


        %WAIT OUT STIMULUS DURATION IN FRAMES
        nFlips = atrial.pageDuration(i) - 1; %WE ALREADY FLIPPED ONCE
        for FlipNumber = 1:nFlips
            %PRESERVE BACK BUFFER IF THIS TEXTURE IS TO BE SHOW AGAIN AT THE NEXT FLIP
            bPreserveBackBuffer = FlipNumber < nFlips;

            %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
            %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
            ASF_xFlip(windowPtr, Stimuli.tex(atrial.pageNumber(i)), Cfg, bPreserveBackBuffer);
        end
    else
        %THE RESPONSE HAS NOT YET BEEN GIVEN
        pageDuration_in_sec = atrial.pageDuration(i)*Cfg.Screen.monitorFlipInterval;
        [x, y, buttons, t0, t1] = ASF_waitForResponse(Cfg, pageDuration_in_sec - tolerance);

        if any(buttons)
            responseGiven = 1;
            %a button has been pressed before timeout
            if Cfg.ResponseTerminatesTrial
                Snd('Play','Quack')
            else
                %THIS IS DIFFERENT WITH RESPECT TO THE RT PAGE FOR THE
                %PAGES FOLLOWING THE RTPAGE
                WaitSecs(pageDuration_in_sec - (t1-t0) -tolerance) %wait out the remainder of the stimulus duration 5ms margin
            end
            this_response.key = find(buttons); %find which button it was
            this_response.RT = (t1 - startRTMeasurement)*1000; %compute response time
        end

    end
end

%IF YOU WANT TO FORCE A RESPONSE
if Cfg.WaitUntilResponseAfterTrial && ~responseGiven
    %[x, y, buttons, t0, t1] = WaitForMousePress(10);
    [x, y, buttons, t0, t1] = ASF_waitForResponse(Cfg, 10);

    if any(buttons)
        responseGiven = 1; %#ok<NASGU>
        %a button has been pressed before timeout
        this_response.key = find(buttons); %find which button it was
        this_response.RT = (t1 - startRTMeasurement)*1000; %compute response time
    end
end

%TRIAL BY TRIAL FEEDBACK
if Cfg.FeedbackTrialCorrect || Cfg.FeedbackTrialError
    %EVALUATE RESPONSE
    if this_response.key == atrial.CorrectResponse
        %CORRECT RESPONSE
        if Cfg.FeedbackTrialCorrect
            Snd('Play', Cfg.sndOK)
            Snd('Wait');
        end
    else
        %WRONG RESPONSE
        if Cfg.FeedbackTrialError
            Snd('Play', Cfg.sndERR)
            Snd('Wait');
        end
    end
end

%PACK INFORMATION ABOUT THIS TRIAL INTO STRUCTURE TrialInfo (THE RETURN ARGUMENT)
%PLEASE MAKE SURE THAT TrialInfo CONTAINS THE FIELDS:
%   trial
%   datestr
%   tStart
%   Response
%   timing
%   startRTMeasurement
%   endRTMeasurement
%OTHERWISE DIAGNOSTIC PROCEDURES OR ROUTINES FOR DATAANALYSIS MAIGHT FAIL
TrialInfo.trial = atrial;  %store page numbers and durations
TrialInfo.datestr = strDate;
TrialInfo.tStart = tStart;
TrialInfo.Response = this_response;
TrialInfo.timing = timing;
TrialInfo.startRTMeasurement = startRTMeasurement;
TrialInfo.endRTMeasurement = endRTMeasurement;

function checkforuserabort(windowPtr, Cfg);

[bUpDn, T, keyCodeKbCheck] = KbCheck;
if bUpDn % break out of loop
    if find(keyCodeKbCheck) == 81
        fprintf(1, 'USER ABORTED PROGRAM\n');
        ASF_PTBExit(windowPtr, Cfg, 1)
        %FORCE AN ERROR
        error('USERABORT')
        %IF TRY/CATCH IS ON THE FOLLOWING LINE CAN BE COMMENTED OUT
        %PTBExit(windowPtr);
    end
end

function Cfg = runBlock(windowPtr, Cfg, blockDurationSecs)
persistent VideoCounter
Cfg.writeVideo = 0;
if isempty(VideoCounter)
    VideoCounter = 0;
end
tBlockStartSecs = GetSecs;
tCurrentSecs = 0;
tLastChangeSecs =  0;
startRTMeasurement = tBlockStartSecs; %endRTMeasurement = 0;

tolerance = 1/400;

this_response.key(1000) = NaN;
this_response.RT(1000) = NaN;
iResponse = 0;

while(tCurrentSecs < blockDurationSecs)
    tCurrentSecs = GetSecs - tBlockStartSecs;
    %EVERY 500ms SOME THINGS CHANGE: 1. COLOR OF FIXATION, 2. MOTION DIRECTION
    if tCurrentSecs >= (tLastChangeSecs + Cfg.Exp.stimulusDurationSecs)
        %PICK A NEW COLOR FOR FIXATION
        while(Cfg.Exp.iColorNew == Cfg.Exp.iColorLast)
            Cfg.Exp.iColorNew = ceil(rand*4);
        end
        Cfg.Fixation.color = Cfg.Exp.cVec(Cfg.Exp.iColorNew, :);
        Cfg.Exp.iColorLast = Cfg.Exp.iColorNew;

        %PICK A NEW DIRECTION FOR MOTION
        while(Cfg.Exp.iMotionDirectionNew == Cfg.Exp.iMotionDirectionLast)
            Cfg.Exp.iMotionDirectionNew = ceil(rand*4);
        end
        Cfg.Dots.update.cohdir = Cfg.Exp.directionVec(Cfg.Exp.iMotionDirectionNew);
        Cfg.Exp.iMotionDirectionLast = Cfg.Exp.iMotionDirectionNew;

        tLastChangeSecs = tCurrentSecs;
        %fprintf(1, '%5.3f, [%03d, %03d, %03d] \n', [tCurrent, Cfg.Fixation.color]);
        %Cfg.Dots.update.cohdir = directionVec(iColorNew); %NOW COLOR AND DIRECTION ARE CONFOUNDED, THIS WILL CHANGE
        Cfg.Dots.update.cohDX = cos(deg2rad(Cfg.Dots.update.cohdir))* Cfg.Dots.update.coh;
        Cfg.Dots.update.cohDY = sin(deg2rad(Cfg.Dots.update.cohdir))* Cfg.Dots.update.coh;

    end
    %SHOW DOTS
    ShowDots(windowPtr, Cfg.Dots, 1, Cfg.Fixation, Cfg)

    pageDuration_in_sec = 0.05;
    [x, y, buttons, t0, t1] = ASF_waitForResponse(Cfg, pageDuration_in_sec - tolerance);
    if any(buttons)
        iResponse = iResponse + 1;
        %a button has been pressed before timeout
        if Cfg.responseTerminatesTrial
            Snd('Play','Quack')
        else
            WaitSecs(pageDuration_in_sec - (t1 - t0) -tolerance) %wait out the remainder of the stimulus duration 5ms margin
        end
        this_response.key(iResponse) = find(buttons); %find which button it was
        this_response.RT(iResponse) = (t1 - startRTMeasurement)*1000; %compute response time
    end

    if Cfg.writeVideo
        VideoCounter = VideoCounter + 1;
        imageArray = Screen('GetImage', windowPtr );
        VideoName = sprintf('cmot%06d.jpg', VideoCounter);
        imwrite(imageArray, VideoName, 'JPG')
    end

    %UPDATE DOTS
    Cfg.Dots = UpdateDots(Cfg.Dots);

    %     [mx, my, buttons] = GetMouse(Cfg.ScreenNumber);
    %     if KbCheck | find(buttons) % break out of loop
    %         break;
    %     end;
end

function Dots = UpdateDots(Dots)

%UPDATE COHERENTLY MOVING DOTS
cases_coherent = find(Dots.iscoherent);
nCoherent = length(cases_coherent);
if nCoherent > 0
    Dots.x(cases_coherent) = Dots.x(cases_coherent) + Dots.update.cohDX;
    Dots.y(cases_coherent) = Dots.y(cases_coherent) + Dots.update.cohDY;
end

%UPDATE INCOHERENTLY MOVING DOTS
cases_incoherent = find(Dots.iscoherent == 0);
nIncoherent = length(cases_incoherent);
if nIncoherent > 0
    dX = rand(Dots.nDots, 1)*Dots.update.randWalkX - Dots.update.randWalkX/2;
    dY = rand(Dots.nDots, 1)*Dots.update.randWalkY - Dots.update.randWalkY/2;

    Dots.x(cases_incoherent) = Dots.x(cases_incoherent) + dX(cases_incoherent);
    Dots.y(cases_incoherent) = Dots.y(cases_incoherent) + dY(cases_incoherent);
end


Cfg.DotsInCircle = 0; %LEAVE IT AT 0

if Cfg.DotsInCircle
    %THIS IS BEAUTIFUL, BUT CREATES A REGRESSION TOWARDS THE LINE OF MOTION
    %CHECK WHETHER POINTS FALL OUTSIDE THE APERTURE
    R2 = (Dots.x - Dots.Aperture.centerX).^2 + (Dots.y - Dots.Aperture.centerY).^2;
    casesOutsideAperture= find( R2 > Dots.Aperture.rad^2);
    nCasesOutsideAperture = length(casesOutsideAperture);
    if nCasesOutsideAperture > 0
        pause(0.1)
        hold on
        plot(Dots.x(casesOutsideAperture) - Dots.Aperture.centerX, Dots.y(casesOutsideAperture) - Dots.Aperture.centerY, 'y.')
        hold off
        %DETERMINE ANGLE OF VECTORS TO DOTS OUTSIDE APERTURE
        alpha = atan(Dots.y(casesOutsideAperture)./Dots.x(casesOutsideAperture));

        %CREATE A VECTOR IN THAT DIRECTION WITH LENGTH 2R
        displacement.x = cos(alpha)*Dots.Aperture.rad*2;
        displacement.y = sin(alpha)*Dots.Aperture.rad*2;
        %     hold on
        %     plot([Dots.x(casesOutsideAperture), Dots.x(casesOutsideAperture)- displacement.x], [Dots.y(casesOutsideAperture), Dots.y(casesOutsideAperture)- displacement.y], 'k')
        %     hold off
        %SUBTRACT THE RESULTING VECTOR FROM POINTS
        Dots.x(casesOutsideAperture) = Dots.x(casesOutsideAperture) - displacement.x;
        Dots.y(casesOutsideAperture) = Dots.y(casesOutsideAperture) - displacement.y;
    end
else
    %Dots live in a square
    casesOutsideApertureXR = find( (Dots.x - Dots.Aperture.centerX) > Dots.Aperture.rad);
    casesOutsideApertureXL = find( (Dots.x - Dots.Aperture.centerX) < -Dots.Aperture.rad);
    casesOutsideApertureYU = find( (Dots.y - Dots.Aperture.centerY) > Dots.Aperture.rad);
    casesOutsideApertureYL = find( (Dots.y - Dots.Aperture.centerY) < -Dots.Aperture.rad);

    casesOutsideAperture = unique(vertcat(casesOutsideApertureXR, casesOutsideApertureXL, casesOutsideApertureYU, casesOutsideApertureYL));

    if any(casesOutsideAperture)
        if not(isempty(casesOutsideApertureXR))
            Dots.x(casesOutsideApertureXR) = Dots.x(casesOutsideApertureXR) -  2*Dots.Aperture.rad;
        end
        if not(isempty(casesOutsideApertureXL))
            Dots.x(casesOutsideApertureXL) = Dots.x(casesOutsideApertureXL) +  2*Dots.Aperture.rad;
        end
        if not(isempty(casesOutsideApertureYU))
            Dots.y(casesOutsideApertureYU) = Dots.y(casesOutsideApertureYU) -  2*Dots.Aperture.rad;
        end
        if not(isempty(casesOutsideApertureYL))
            Dots.y(casesOutsideApertureYL) = Dots.y(casesOutsideApertureYL) +  2*Dots.Aperture.rad;
        end
    end

end


function Dots = InitDots(Dots)

%INITIALIZE DOTS WITH A RANDOM POSITION INSIDE (!!!!) AN APERTURE

%POSITION
Dots.x = ceil(rand( Dots.nDots, 1)*Dots.nCols);
Dots.y = ceil(rand( Dots.nDots, 1)*Dots.nRows);

bAllDotsInsideAperture = 0;

% while not(bAllDotsInsideAperture)
%     %FIND DOTS THAT ARE OUTSIDE RADIUS DISTANCE R OF THE CENTER OF THE APERTURE
%     casesOutsideAperture= find( (Dots.x - Dots.Aperture.centerX).^2 + (Dots.y - Dots.Aperture.centerY).^2 > Dots.Aperture.rad^2);
%     nCasesOutsideAperture = length(casesOutsideAperture);
%     if nCasesOutsideAperture > 0
%         Dots.x(casesOutsideAperture) = ceil(rand( nCasesOutsideAperture, 1)*Dots.nCols);
%         Dots.y(casesOutsideAperture) = ceil(rand( nCasesOutsideAperture, 1)*Dots.nRows);
%     else
%         bAllDotsInsideAperture = 1;
%     end
% end
%


Dots.iscoherent(Dots.nDots, 1) = 0;

%COHERENTLY OR INCOHERENTLY MOVING
%determin e n Dots that move coherently
nCoherent = Dots.nDots * Dots.coherenceLevel;

randvec = randperm(Dots.nDots);
cases_coherent = randvec(1:nCoherent);
Dots.iscoherent(cases_coherent) = 1;

function ShowDots(windowPtr, Dots, useBackBuffer, fixPoint, Cfg)

%FIND DOTS THAT ARE WITHIN RADIUS DISTANCE R OF THE CENTER OF THE APERTURE
cases = find( (Dots.x - Dots.Aperture.centerX).^2 + (Dots.y - Dots.Aperture.centerY).^2 <= Dots.Aperture.rad^2);
nCases = length(cases);


%VECTORIZED VERSION
%[,size] [,color] [,center] [,dot_type])
myTimeStamp = zeros(1, 5);
for i = 1:1
    if Dots.lum >= 0
        %Screen('DrawDots', windowPtr, [Dots.x, Dots.y]', Dots.dotSize, Dots.color*Dots.lum/100, [], 2 );
        Screen('DrawDots', windowPtr, [Dots.x(cases), Dots.y(cases)]', Dots.dotSize, fix((Dots.color*Dots.lum)/100), [], 2 );
    end
    switch fixPoint.shape
        %case -1 do nothing
        case 1
            %CIRCLE (THIS IS THE ATTEND TO CENTER CONDITION)
            Screen('DrawDots', windowPtr, [Cfg.Screen.width/2, Cfg.Screen.height/2]', 20, fixPoint.color, [], 2 );
        case 2
            %SQUARE (THIS IS THHE ATTEND MOVING STIMULI CONDITION
            Screen('FillRect', windowPtr, fixPoint.color, CenterRect([0 0 20 20], Cfg.Screen.rect));
    end

    % Screen('Flip', windowPtr);
    Cfg.UseBackBuffer = 1;%useBackBuffer;
    [ VBLTimestamp, StimulusOnsetTime, FlipTimestamp, Missed, Beampos ] = ASF_xFlip(windowPtr, [], Cfg, 0);
    myTimeStamp(i) = VBLTimestamp;
end
%myTimeStamp
function rad = deg2rad(deg)
rad = deg/180*pi;

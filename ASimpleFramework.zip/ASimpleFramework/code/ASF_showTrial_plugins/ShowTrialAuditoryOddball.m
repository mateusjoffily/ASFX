%% ShowTrialAuditoryOddBall (SHOWTRIAL WITH MOUSE AS RESPONSE DEVICE)
function [this_response, timing, StartRTMeasurement, EndRTMeasurement] = ShowTrialAuditoryOddball(atrial, windowPtr, tex, cfg)
%SAVE TIME BY ALLOCATING ALL VARIABLES UPFRONT

    % VBLTimestamp system time (in seconds) when the actual flip has happened in the return argument
    % StimulusOnsetTime An estimate of Stimulus-onset time
    % FlipTimestamp is a timestamp taken at the end of Flip's execution
    % Use the difference between FlipTimestamp and VBLTimestamp to get an estimate of how long Flips execution takes.
    % Missed indicates if the requested presentation deadline for your stimulus has been missed. A negative
    % value means that dead- lines have been satisfied. Positive values indicate a deadline-miss.
    % Beampos is the position of the monitor scanning beam when the time measurement was taken (useful for correctness tests)
VBLTimestamp = 0; StimulusOnsetTime = 0; FlipTimestamp = 0; Missed = 0; Beampos = 0;

StartRTMeasurement = 0; EndRTMeasurement = 0;
timing = [0, VBLTimestamp, StimulusOnsetTime, FlipTimestamp, Missed, Beampos];
npages = length(atrial.pagenumber);
timing(npages, end) = 0;
this_response = [];

tolerance = 1/400;
%responseGiven = 0;
this_response.key = [];
this_response.RT = [];

tones = MakeTones([750, 1000]); %FOR ODDBALL
%tones = MakeTones([500, 1000]); %FOR EYESOPENCLOSE

this_response.keyOddball(npages) = 0;
this_response.RTOddball(npages) = 0; 

%SPECIAL TREATMENT FOR THE DISPLAY PAGE ON WHICH WE ALLOW REACTIONS
%RT PAGE
for i = 1:npages
    %PUT THE APPROPRIATE TEXTURE ON THE BACK BUFFER
    Screen('DrawTexture', windowPtr, tex(atrial.pagenumber(i)));

    %DO NOT PUT THIS PAGE AGAIN ON THE BACKBUFFER, WE WILL WAIT IT OUT
    %USING THE TIMER NOT FLIPPING
    bPreserveBackBuffer = 0;

    %FLIP THE CONTENT OF THIS PAGE TO THE DISPLAY AND PRESERVE IT IN THE
    %BACKBUFFER IN CASE THE SAME IMAGE IS TO BE FLIPPED AGAIN TO THE SCREEN
    [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = xFlip(windowPtr, tex(atrial.pagenumber(i)), cfg, bPreserveBackBuffer);

    %SET TRIGGER
    setTrigger(cfg, atrial.pagenumber(i));
    
    %PLAY SOUND HERE
    switch(atrial.pagenumber(i))
        case 2
            Snd('Play', tones(1, :), cfg.Fs)
        case 3
            Snd('Play', tones(2, :), cfg.Fs)
    end
    
    % other signal for Veronica Mazza's EEG - GP ????
    setTrigger(cfg, 8);
    

    StartRTMeasurement = VBLTimestamp;

    timing(i, 1:6) = [atrial.pageduration(i), VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos];

    pageDuration_in_sec = atrial.pageduration(i)*cfg.MonitorFlipInterval;
    %WAS
    %[x, y, buttons, t0, t1] = WaitForMousePress(pageDuration_in_sec - tolerance);
    [x, y, buttons, t0, t1] = WaitForResponse(cfg, pageDuration_in_sec - tolerance);
    if any(buttons)
        %responseGiven = 1;
        %a button has been pressed before timeout
        if cfg.ResponseTerminatesTrial
            Snd('Play','Quack')
        else
            WaitSecs(pageDuration_in_sec - (t1 - StartRTMeasurement) -tolerance) %wait out the remainder of the stimulus duration 5ms margin
        end
        this_response.keyOddball(i) = find(buttons); %find which button it was
        this_response.RTOddball(i) = (t1 - StartRTMeasurement)*1000; %compute response time
    else
        this_response.keyOddball(i) = NaN;
        this_response.RTOddball(i) = NaN; 
    end
end



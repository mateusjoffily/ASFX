% ASF_pulseTrainNI('init')
% ASF_pulseTrainNI('createPulseTask')
% ASF_pulseTrainNI('startPulseTask')
% ASF_pulseTrainNI('stopPulseTask')
% ASF_pulseTrainNI('clearPulseTask')
% ASF_pulseTrainNI('shutDown')

pulseFrequencyHz = 5;
iNumberOfPulses = 5;
taskh1 = libpointer('uint32Ptr', 0);
taskh1 = ASF_PulseTrainCreateTask(taskh1, pulseFrequencyHz, iNumberOfPulses)

for i = 1:10
    ASF_PulseTrainStartPulseTask(taskh1);
    pause(2)
    %pause(1/pulseFrequencyHz*iNumberOfPulses*2)%WAIT FOR TWICE THE LENGTH OF THE SEQUENCE
    ASF_PulseTrainStopPulseTask(taskh1);
end

[status, taskh1] = ASF_PulseTrainClearPulseTask(taskh1);

ASF_PulseTrainUnloadNIDAQmx
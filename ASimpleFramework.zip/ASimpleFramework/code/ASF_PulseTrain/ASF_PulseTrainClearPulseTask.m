function [status, taskh1] = ASF_PulseTrainClearPulseTask(taskh1)
status = calllib('NIDAQmx', 'DAQmxClearTask', taskh1.value);
taskh1.value = -1;

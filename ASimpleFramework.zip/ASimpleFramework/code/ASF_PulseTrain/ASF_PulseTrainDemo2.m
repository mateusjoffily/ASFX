function ASF_PulseTrainDemo2
% ASF_pulseTrainNI('init')
% ASF_pulseTrainNI('createPulseTask')
% ASF_pulseTrainNI('startPulseTask')
% ASF_pulseTrainNI('stopPulseTask')
% ASF_pulseTrainNI('clearPulseTask')
% ASF_pulseTrainNI('shutDown')

pulseFrequencyHz = 9;
iNumberOfPulses = 5;

taskh1 = libpointer('uint32Ptr', 0);
taskh1 = ASF_PulseTrainCreateTask(taskh1, pulseFrequencyHz, iNumberOfPulses);


for i = 1:10
    ASF_PulseTrainStartPulseTask(taskh1);
    tic
    while not(ASF_PulseTrainIsTaskDone(taskh1))
        %HERE YOU CAN STILL DO SOME STIMULUS RENDERING
    end
    % int32 _stdcall DAQmxWaitUntilTaskDone ( TaskHandle taskHandle , float64 timeToWait ); 
    %status = calllib('NIDAQmx', 'DAQmxWaitUntilTaskDone', taskh1.value, 1.0);
    toc
    ASF_PulseTrainStopPulseTask(taskh1);
    pause(2)
end

[status, taskh1] = ASF_PulseTrainClearPulseTask(taskh1);

ASF_PulseTrainUnloadNIDAQmx


function isTaskDone = ASF_PulseTrainIsTaskDone(taskh1)
%the zero parameter is a dummy for a pointer bool *isTaskDone
[status, isTaskDone] = calllib('NIDAQmx', 'DAQmxIsTaskDone', taskh1.value, 0);
return
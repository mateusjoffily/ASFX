function status = ASF_PulseTrainStopPulseTask(taskh1)
status = calllib('NIDAQmx', 'DAQmxStopTask', taskh1.value);

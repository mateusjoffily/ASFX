function isTaskDone = ASF_PulseTrainIsTaskDone(taskh1)
%the zero parameter is a dummy for a pointer bool *isTaskDone
[status, isTaskDone] = calllib('NIDAQmx', 'DAQmxIsTaskDone', taskh1.value, 0);
return
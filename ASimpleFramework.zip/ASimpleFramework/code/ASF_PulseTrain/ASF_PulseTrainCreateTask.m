function [taskh1, errorFlag] = ASF_PulseTrainCreateTask(taskh1, pulseFrequencyHz, iNumberOfPulses)
%function ASF_InitPulseTrainNI(varargin)
%PULSE TRAIN LIBRARY
%jens schwarzbach 20080121
% persistent DAQmx_Val_Hz DAQmx_Val_High DAQmx_Val_Low DAQmx_Val_FiniteSamps DAQmx_Val_ContSamps DAQmx_Val_HWTimedSinglePoint
% persistent taskh1
% currentCommand = varargin{1};
errorFlag = 0;

%MAKE SURE LIBRARY IS LOADED
if not(libisloaded('NIDAQmx'))
    %taskh1 = libpointer('uint32Ptr', 0);
    %LOAD LIBRARY
    %NEED TO FIND OUT WETHER THERE IS A LESS OBSCURE LIBRARY
    libName = 'C:\WINDOWS\System32\nicaiu.dll';
    headerFile = 'C:\Program Files\National Instruments\NI-DAQ\DAQmx ANSI C Dev\include\NIDAQmx.h';
    fprintf(1, 'INITIALIZING NATIONAL INSTRUMENTS CARD FOR PULSE TRAINS ...\n');
    fprintf(1, '\tLOADING LIBRARY FILE %s ...', libName);
    [notfound, warnings] = loadlibrary(libName, headerFile, 'alias', 'NIDAQmx', 'mfilename', 'infoNIDAQmx.m');
    fprintf(1, '\tDONE\n');
    if libisloaded('NIDAQmx')
        fprintf(1, 'LIBRARY NIDAQmx NOW AVAILABLE\n');
    else
        error('ERROR LOADING NIDAQmx LIBRARY\n')
        notfound
        warnings
        errorFlag = 1
        return
    end
    %NOT YET USED
    %[methodinfo, structs, enuminfo] = infoNIDAQmx;

    %DEFINE SOME CONSTANTS
    DAQmx_Val_Hz = 10373;% Hz
    DAQmx_Val_High = 10192;% // High
    DAQmx_Val_Low =  10214;% // Low

    DAQmx_Val_FiniteSamps = 10178; %Finite Samples
    DAQmx_Val_ContSamps = 10123; %Continuous Samples
    DAQmx_Val_HWTimedSinglePoint = 12522; % Hardware Timed Single Point

end

%CREATE TASK
%int32 DAQmxCreateTask (const char taskName[], TaskHandle *taskHandle);
%taskh1 = libpointer('uint32Ptr', 0);
taskname = 'PulseTask';
[a, b, c] = calllib('NIDAQmx', 'DAQmxCreateTask', taskname, taskh1); % create task taskh1
if a < 0
    fprintf(1, 'Cannot create task %s.\n', taskname)
    errorFlag = 1;
    return
end

%int32 DAQmxCreateCOPulseChanFreq (TaskHandle taskHandle, const char counter[], const char nameToAssignToChannel[], int32 units, int32 idleState, float64 initialDelay, float64 freq, float64 dutyCycle);


[a, b, c] = calllib('NIDAQmx','DAQmxCreateCOPulseChanFreq', taskh1.value, 'Dev2/ctr0','', DAQmx_Val_Hz, DAQmx_Val_Low, 0.0, pulseFrequencyHz, 0.5);
%    DAQmxErrChk (DAQmxCreateCOPulseChanFreq(*taskHandle,"Dev2/ctr0","",DAQmx_Val_Hz,DAQmx_Val_Low,0.0, dFrequency, dRatioUpTime));

[a] = calllib('NIDAQmx','DAQmxCfgImplicitTiming', taskh1.value, DAQmx_Val_FiniteSamps, iNumberOfPulses);
%DAQmxErrChk (DAQmxCfgImplicitTiming(*taskHandle, DAQmx_Val_FiniteSamps, iNumberOfSamples));



% switch currentCommand
% 
% 
%     case 'createPulseTask'
%         %int32 DAQmxCreateTask (const char taskName[], TaskHandle *taskHandle);
%         %        taskh1 = libpointer('uint32Ptr', 0);
%         %         taskname = 'PulseTask';
%         %         [a, b, c] = calllib('NIDAQmx', 'DAQmxCreateTask', taskname, taskh1); % create task taskh1
% 
%         taskh1 = libpointer('uint32Ptr',0);
%         taskname = 'SampleTask';
%         [a, b, c] = calllib('NIDAQmx','DAQmxCreateTask', taskname, taskh1); % erzeuge Task taskh1
%         %taskh1=libpointer('uint32Ptr',taskh1);
% 
% 
% 
%         if a < 0
%             fprintf(1, 'Cannot create task %s.\n', taskname)
%             return
%         end
%         DAQmx_Val_Hz = 20;
%         DAQmx_Val_Low = 0;
%         %int32 DAQmxCreateCOPulseChanFreq (TaskHandle taskHandle, const char counter[], const char nameToAssignToChannel[], int32 units, int32 idleState, float64 initialDelay, float64 freq, float64 dutyCycle);
% 
% 
%         [a, b, c] = calllib('NIDAQmx','DAQmxCreateCOPulseChanFreq', taskh1.value, 'Dev2/ctr0','', DAQmx_Val_Hz, DAQmx_Val_Low, 0.0, 10, 0.5);
%         %    DAQmxErrChk (DAQmxCreateCOPulseChanFreq(*taskHandle,"Dev2/ctr0","",DAQmx_Val_Hz,DAQmx_Val_Low,0.0, dFrequency, dRatioUpTime));
% 
%         [a] = calllib('NIDAQmx','DAQmxCfgImplicitTiming', taskh1.value, DAQmx_Val_FiniteSamps, 20);
%         %DAQmxErrChk (DAQmxCfgImplicitTiming(*taskHandle, DAQmx_Val_FiniteSamps, iNumberOfSamples));
% 
%     case 'startPulseTask'
%         [a] = calllib('NIDAQmx', 'DAQmxStartTask', taskh1.value);
% 
%     case 'stopPulseTask'
%         [a] = calllib('NIDAQmx', 'DAQmxStopTask', taskh1.value);
% 
%     case 'clearPulseTask'
%         [a] = calllib('NIDAQmx', 'DAQmxClearTask', taskh1.value);
%         taskh1.value = 0;
% 
%     case 'shutDown'
%         fprintf(1, 'UNLOADING NIDAQmx LIBRARY ... ');
%         if libisloaded('NIDAQmx')
%             unloadlibrary NIDAQmx
%         else
%             fprintf(1, 'LIBRARY WAS NOT LOADED ANYWAY\n')
%             return
%         end
%         if libisloaded('NIDAQmx')
%             fprintf(1, 'LIBRARY STILL LOADED!!!\n');
%         else
%             error('UNLOAD SUCCESS\n')
%         end
% end
% 

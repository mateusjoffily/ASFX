function status = ASF_PulseTrainStartPulseTask(taskh1)
status = calllib('NIDAQmx', 'DAQmxStartTask', taskh1.value);

function ASF_PulseTrainUnloadNIDAQmx
fprintf(1, 'UNLOADING NIDAQmx LIBRARY ... ');
if libisloaded('NIDAQmx')
    unloadlibrary NIDAQmx
else
    fprintf(1, 'LIBRARY WAS NOT LOADED ANYWAY\n')
    return
end
if libisloaded('NIDAQmx')
    fprintf(1, 'LIBRARY STILL LOADED!!!\n');
else
    fprintf(1, 'UNLOAD SUCCESS\n')
end

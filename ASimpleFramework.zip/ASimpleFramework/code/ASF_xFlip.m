%function [ VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos ] = ASF_xFlip(windowPtr, texture, cfg, bPreserveBackBuffer)
%% ASF_xFlip (extended Screen('Flip'))
function [ VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos ] = ASF_xFlip(windowPtr, texture, cfg, bPreserveBackBuffer)
% persistent flipval
% 
% if isempty( flipval )
%     flipval = 0;
% end

[bUpDn, T, keyCodeKbCheck] = KbCheck;
if bUpDn % break out of loop
    if find(keyCodeKbCheck) == 81
        fprintf(1, 'USER ABORTED PROGRAM\n');
        ASF_PTBExit(windowPtr, cfg, 1)
        %FORCE AN ERROR
        error('USERABORT')
        %IF TRY/CATCH IS ON THE FOLLOWING LINE CAN BE COMMENTED OUT
        %PTBExit(windowPtr);
    end
end

switch bPreserveBackBuffer
    case 0 %DESTRUCTIVE FLIP
            [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = Screen('Flip', windowPtr);
    case 1 %NONDESTRUCTIVE FLIP
        if cfg.Screen.useBackBuffer
            %FOR A MACHINE THAT HAS AUXILIARY BACKBUFFERS
            [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = Screen('Flip', windowPtr, [], 1);
        else
            %FOR A MACHINE THAT HAS NO BACKBUFFERS
            [VBLTimestamp StimulusOnsetTime FlipTimestamp Missed Beampos] = Screen('Flip', windowPtr);
            %--------------------------------------------------------------
            % Draw many textures at once - Modified by Mateus Joffily
            %--------------------------------------------------------------
            if numel(texture) == 1
                Screen('DrawTexture', windowPtr, texture);
            else
                Screen('DrawTextures', windowPtr, texture);
            end
            %--------------------------------------------------------------
        end
end

function dprime_CrowdingEccentricity(subVec)

%dprime_CrowdingEccentricity([5])
%dprime_CrowdingEccentricity([1 2 3])
Cfg.fsize = 24;
Cfg.msize = 16;
Cfg.thres = .75;
nblocks =3;%7
[x, dprime] = readData(subVec, nblocks, Cfg);
% 


function [x, dprime] = readData(subVec, nblocks, Cfg)
    res = [];
for sub = 1 : length(subVec);
    % fname = sprintf('%s_%d.mat', char(subjects{sub}), block);
    for i =1:nblocks
    %for i = 1:2
        fname = sprintf('%02d_%02d.mat', subVec(sub), i);
        load (fname);
        ares = read_dat(ExpInfo);
        %ASF_decode([1:1:20], [5, 4]);
        %  1: 7  -8, -4, -2, 0, 2, 4, 8, print size 1
        %  8:14  -8, -4, -2, 0, 2, 4, 8, print size 2
        % 15:21  -8, -4, -2, 0, 2, 4, 8, print size 3
        % 22:28  -8, -4, -2, 0, 2, 4, 8, print size 4
        % 29:35  -8, -4, -2, 0, 2, 4, 8, print size 5
        if isempty(res)
            res = ares;
        else
            res = [res; ares];
        end
    end
    
    indFast = find(res(:,2)<200);
    res(indFast, :) = [];
%     
    %delete NaNs
    ind = isnan(res(:,2));
    ind = find(ind==1);
    res(ind, :)=[];
    
   
    
    count = 0;
    for crowd = 1 : 5
        for pos = 1 : 7
            count = count + 1;
            thisInd = find(res(:,1) ==count);
            thisDatCorrect = find(res(:,1)==count & (res(:,3)==res(:,4)));
            %thisDatWrong = find(res(:,1)==count & (res(:,3)~=res(:,4)));
            %if isempty(thisDatCorrect)
            %    PCORR(pos, crowd) = 0.5;
            %else
            PCORR(pos, crowd) = length(thisDatCorrect)/length(thisInd);
            %end
            rtTrimmed = trim_dat(res(thisDatCorrect, 2));
            RT(pos, crowd) = nanmean(res(thisDatCorrect, 2));
            RTtrimmed(pos, crowd) = nanmean(rtTrimmed);
            
            casesHit_uprightT   = find(res(:,1)==count & (res(:,3)==1) &(res(:,4)==1));
            casesFA_uprightT    = find(res(:,1)==count & (res(:,3)==3) &(res(:,4)==1));
            casesCR_uprightT    = find(res(:,1)==count & (res(:,3)==3) &(res(:,4)==3));
            casesMiss_uprightT  = find(res(:,1)==count & (res(:,3)==1) &(res(:,4)==3));
            casesHit_tiltedT    = find(res(:,1)==count & (res(:,3)==3) &(res(:,4)==3));
            casesFA_tiltedT     = find(res(:,1)==count & (res(:,3)==1) &(res(:,4)==3));
            casesCR_tiltedT     = find(res(:,1)==count & (res(:,3)==1) &(res(:,4)==1));
            casesMiss_tiltedT   = find(res(:,1)==count & (res(:,3)==3) &(res(:,4)==1));
            
            if isempty(casesHit_uprightT)
                dprime(pos, crowd) = 0
            else

                dprimeUpright = calc_dprime(length(casesHit_uprightT), length(casesMiss_uprightT), length(casesCR_uprightT), length(casesFA_uprightT));
                dprimeTilted  = calc_dprime(length(casesHit_tiltedT), length(casesMiss_tiltedT), length(casesCR_tiltedT), length(casesFA_tiltedT));
                dprime(pos, crowd) = mean([dprimeUpright, dprimeTilted]);
            end

        end
    end
end


    %upright Ts
    
    figure;
    x = [-5.25 -2.25 -0.75 0 0.75 2.25 5.25]
    h=plot(x, nanmean(dprime'));
    set(h, 'linewidth', 2, 'marker', 'o', 'markersize', Cfg.msize, 'markerfacecolor', 'w', 'color', 'k');
    set(gca, 'fontsize', Cfg.fsize-4, 'linewidth', 2);
    set(gca, 'xtick', x);
    hxlab=xlabel('visual field location');
    hylab=ylabel('dprime');
    set(hxlab, 'fontsize', Cfg.fsize);
    set(hylab, 'fontsize', Cfg.fsize);
    %set(gca,'xscale', 'log');
    axis([-6 6 0 2.5]);
    
    
    figure;
    x = [0.04 0.08 0.16 0.32 0.64];
    %x = [-6 -4 -2 0 2 4 6]
    h=plot(x, nanmean(dprime));
    set(h, 'linewidth', 2, 'marker', 'o', 'markersize', Cfg.msize, 'markerfacecolor', 'w', 'color', 'k');
    set(gca, 'fontsize', Cfg.fsize-4, 'linewidth', 2);
    set(gca, 'xtick', x);
    hxlab=xlabel('print size (deg.)');
    hylab=ylabel('dprime');
    set(hxlab, 'fontsize', Cfg.fsize);
    set(hylab, 'fontsize', Cfg.fsize);
    set(gca,'xscale', 'log');
    axis([0 0.75 -2 4]);
    
        
    figure;
    myMap = [0 0 0; 0.5 0.5 0.5; 1 1 1; 1 0 0];
    %x = repmat(x, 5,1);
    
    for i = 1 : 4
        h(i) = plot(x, dprime(i,:)');
        %h(i)=plot(PCORR);
        set(h(i), 'linewidth', 2, 'marker', 'o', 'markersize', Cfg.msize, 'markerfacecolor', myMap(i,:), 'color', 'k');
        hold on;
        
    end
    set(gca, 'fontsize', Cfg.fsize-4, 'linewidth', 2);
    set(gca, 'xtick', x(1,:));
    axis([0 0.75 -2 4]);
    hxlab=xlabel('print size');
    hylab=ylabel('dprime');
    set(hxlab, 'fontsize', Cfg.fsize);
    set(hylab, 'fontsize', Cfg.fsize);
    hleg = legend([h(1), h(2), h(3), h(4)],'-5.25', '-2.25', '-0.75', '0', 'location', 'southeast');
    set(hleg, 'fontsize', Cfg.fsize -4, 'box', 'off');
%     switch Cfg.expType
%         case 'contrast'
             set(gca, 'xscale', 'log');
%     end 

figure;
    myMap = [1 0 0; 1 1 1; 0.5 0.5 0.5; 0 0 0];
    %x = repmat(x, 5,1);
    %x = [1:1:5];
    for i = 4 : 7
        h(i) = plot(x, dprime(i,:)');
        %h(i)=plot(PCORR);
        set(h(i), 'linewidth', 2, 'marker', 'o', 'markersize', Cfg.msize, 'markerfacecolor', myMap(i-3,:), 'color', 'k');
        hold on;
    end
    set(gca, 'fontsize', Cfg.fsize-4, 'linewidth', 2);
    set(gca, 'xtick', x(1,:));
    %axis([0.5 5.5 0 1]);
    axis([0 0.75 -2 4]);
    hxlab=xlabel('print size');
    hylab=ylabel('dprime');
    set(hxlab, 'fontsize', Cfg.fsize);
    set(hylab, 'fontsize', Cfg.fsize);
    hleg = legend([h(4), h(5), h(6), h(7)],'0', '0.75', '2.25', '5.25', 'location', 'best');
    set(hleg, 'fontsize', Cfg.fsize -4, 'box', 'off');
%     switch Cfg.expType
%         case 'contrast'
             set(gca, 'xscale', 'log');
%     end 


figure;
    myMap = [0 0 0; 0.25 0.25 0.25; 0.5 0.5 0.5; 0.75 0.75 0.75; 1 1 1];
    %myMap = [0 0 0; 0.17 0.17 0.17; 0.34 0.34 0.34; 0.51 0.51 0.51; 0.68 0.68 0.68; 0.85 0.85 0.85; 1 1 1];
    %x = repmat(x, 5,1);
    x = [-5.25 -2.25 -0.75 0 0.75 2.25 5.25];
    for i = 1 : 5
        h(i) = plot(x, dprime(:,i));
        %h(i)=plot(PCORR);
        set(h(i), 'linewidth', 2, 'marker', 'o', 'markersize', Cfg.msize, 'markerfacecolor', myMap(i,:), 'color', 'k');
        hold on;
        
    end
    set(gca, 'fontsize', Cfg.fsize-4, 'linewidth', 2);
    set(gca, 'xtick', x(1,:));
    axis([-7.5 7.5 -2 4]);
    hxlab=xlabel('vertical position');
    hylab=ylabel('dprime');
    set(hxlab, 'fontsize', Cfg.fsize);
    set(hylab, 'fontsize', Cfg.fsize);
    % = [0.04 0.08 0.16 0.32 0.64]
    %hleg = legend([h(1), h(2), h(3), h(4), h(5)],'0.05', '0.07', '0.1', '0.2', '0.4', 'location', 'best');
    hleg = legend([h(1), h(2), h(3), h(4), h(5)],'0.04', '0.08', '0.16', '0.32', '0.64', 'location', 'best');
    set(hleg, 'fontsize', Cfg.fsize -4, 'box', 'off');

% 
x = [0.04 0.08 0.16 0.32 0.64]';
for i = 1 : 7
    figure;
    [r(i), t0(i)] = fitLogFun(x', dprime(i,:));
end
% figure;
% plot([-5.25 -2.25 -0.75 0 0.75 2.25 5.25], xEst, 'ro-');
%     
%     t=1;

figure;
plot([-5.25 -2.25 -0.75 0 0.75 2.25 5.25], t0);
t=1

    
    function res = read_dat(expinfo)
%function res = ASF_readExpInfo(expinfo)
%PACK DATA FROM EXPINFO INTO A MATRIX
%ROW -> trial
%COL 1: CODE
%COL 2: RT
%COL 3: KEY
%COL 4: CRESP
nTrials = length(expinfo.TrialInfo);
if nTrials == 0
    fprintf(1, 'WARNING NO TRIALS SAVED!\n')
    res = [];
else
    %res(nTrials, 3) = 0;
    for i = 2:nTrials - 1
        %for i=1:nTrials
        %res(i, 1) = expinfo.TrialInfo(i).trial.code;
        thisResponse = expinfo.TrialInfo(i).Response;
        res(i, 1) = expinfo.TrialInfo(i).trial.code;
        res(i, 4) = expinfo.TrialInfo(i).trial.correctResponse;
        if isempty(thisResponse.RT)
            res(i, 2:3) = NaN;
          else
            %res(i, 1) = expinfo.TrialInfo(i).trial.code;
            res(i, 2) = thisResponse.RT;
            res(i, 3) = thisResponse.key(1); %IF YOU WNAT MULTIPLE KEYS MAKE IT A CELL
            %res(i, 4) = expinfo.TrialInfo(i).trial.correctResponse;
        end
    end
end
function plotEyeData(subject)
%plotEyeData(4)
nBlocks = 20;
startBlock = 1;
vertThresPix = 25; %range of accepted fixation position range; this corresponds to 0.5 deg;
screen.width = 1280;
screen.height = 1024;
doPlot = 1;

%figure;
%for subject = 3 : 6
%for subject = 3 : 6
for i = startBlock : startBlock + nBlocks - 1
    %dat2asc('C:\applications\Projects\Angelika\CrowdingStaircase\data\01_06') ;
    %[trialinfo, eyedata]=develop('C:\applications\Projects\Angelika\CrowdingStaircase\data\01_06_s.asc');
    %dat2asc(sprintf('C:\\applications\\Projects\\Angelika\\CrowdingStaircase\\data\\%02d_%02d', subject, i));
    %[trialinfo, eyedata]=develop(sprintf('C:\\applications\\Projects\\Angelika\\CrowdingStaircase\\data\\%02d_%02d.asc', subject, i));
    %save(sprintf('%02d_%02d_eye.mat', subject, i), 'eyedata');
    load(sprintf('%02d_%02d_eye.mat', subject, i));

    if doPlot == 1
        figure;
        h1 = plot(eyedata(2).FIX.x, eyedata(2).FIX.y, 'ko-');
        set(h1, 'markersize', 8);
        hold on;
        axis image;
        axis([0 screen.width 0 screen.height]);
        htit = title(sprintf('subject %02d, block %02d', subject, i));
        set(htit, 'fontsize', 14)
        set(gca, 'fontsize', 14);
    end
    
    if std(eyedata(2).FIX.y) > vertThresPix %discard block if standard deviation of vertical eye position is > 25 pix
        evaluation(i) = 0;
    else
        evaluation(i) = 1;
    end
    %evaluation(i) = input('please enter 1 for accept and 2 for discard:  ');
    
    %t = 1;
    
    %disp('Please);
    %waitforbuttonpress;
end

save (sprintf('%02d_eyePosEval', subject), 'evaluation');


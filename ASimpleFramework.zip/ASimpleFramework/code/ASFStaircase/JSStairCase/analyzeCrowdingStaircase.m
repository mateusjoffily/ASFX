function [thresUpper, thresLower, startValUpper, startValLower] = analyzeCrowdingStaircase(subject, nBlocks, startBlock, vertThresPix)
%function [thresUpper, thresLower, startValUpper, startValLower] = analyzeCrowdingStaircase(subject, nBlocks)
%
%[thresUpper, thresLower, startValUpper, startValLower] = analyzeCrowdingStaircase(1, 6, 1, 50)
%[thresUpper, thresLower, startValUpper, startValLower] = analyzeCrowdingStaircase(1, 6, 11, 50)
%[thresUpper, thresLower, startValUpper, startValLower] = analyzeCrowdingStaircase(2, 6, 1, 50)
%[thresUpper, thresLower, startValUpper, startValLower] = analyzeCrowdingStaircase(2, 6, 7, 50)
%[thresUpper, thresLower, startValUpper, startValLower] = analyzeCrowdingStaircase(4, 10, 1, 50)
%[thresUpper, thresLower, startValUpper, startValLower] = analyzeCrowdingStaircase(4, 10, 11, 50)

%nBlocks = 6;
%subject = 7;
%subject = 4;
%thres.upper = zeros(nBlocks/2, 1);
%thres.lower = zeros(nBlocks/2, 1);
count.upper = 0;
count.lower = 0;
%vertThresPix = 50;
%count.block = 0;

%check if we have eye movement data from this participant
if exist(sprintf('%02d_%02d_eye.mat', subject, 1));
%    load(sprintf('%02d_%02d_eye.mat', subject, i));
    [validBlockVec, nValidBlocks] = evalVertEyePos(subject, vertThresPix, nBlocks, startBlock);
else 
    %validBlockVec = [startBlock:1:startBlock + nBlocks - 1];
    validBlockVec = 1:1:nBlocks;
    disp('warning: no eye movement data available for this participant');
end

%if exptype is flanker, validBlockVec starts with startBlock instead of 1!
%read in first block that is contained in validBlockVec and check for trial
%type; adjust validBlockVec for trialType flanker
load (sprintf('%02d_%02d.mat', subject, startBlock));
switch ExpInfo.Cfg.staircase.trialType
    case 'flanker'
        validBlockVec = validBlockVec + startBlock -1;
end

disp(sprintf('using %d out of %d blocks for analysis', length(validBlockVec), nBlocks));

for i = 1 : length(validBlockVec)
    thisBlock = validBlockVec(i);
    load (sprintf('%02d_%02d.mat', subject, thisBlock));
    if ExpInfo.Cfg.pos.targetEccYDeg < 0
        count.upper = count.upper + 1;
        switch ExpInfo.Cfg.staircase.trialType
            case 'single'
                thres.upper (count.upper)      = mean(ExpInfo.TrialInfo(2).trial.thresVecCPD(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                thresVec.upper(count.upper, :) = ExpInfo.TrialInfo(2).trial.thresVecCPD;
            case 'flanker'
                %thres.upper (count.upper)      = mean(ExpInfo.TrialInfo(2).trial.thresDeg(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                %thresVec.upper(count.upper, :) = ExpInfo.TrialInfo(2).trial.thresDeg;
                thres.upper (count.upper)      = mean(ExpInfo.TrialInfo(2).trial.thresVecDeg(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                thresVec.upper(count.upper, :) = ExpInfo.TrialInfo(2).trial.thresVecDeg;
        end
    else
        if ExpInfo.Cfg.pos.targetEccYDeg > 0
            count.lower = count.lower + 1;
            switch ExpInfo.Cfg.staircase.trialType
                case 'single'
                    thres.lower (count.lower)      = mean(ExpInfo.TrialInfo(2).trial.thresVecCPD(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                    thresVec.lower(count.lower, :) = ExpInfo.TrialInfo(2).trial.thresVecCPD;
                case 'flanker'
                    %thres.lower (count.lower)      = mean(ExpInfo.TrialInfo(2).trial.thresDeg(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                    %thresVec.lower(count.lower, :) = ExpInfo.TrialInfo(2).trial.thresDeg;
                    thres.lower(count.lower)       = mean(ExpInfo.TrialInfo(2).trial.thresVecDeg(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                    thresVec.lower(count.lower, :) = ExpInfo.TrialInfo(2).trial.thresVecDeg;

            end
        end
    end
end
   

figure;
%h1 = plot(mean(thresVec.upper)');
h1 = errorbar([1:1:20], mean(thresVec.upper)', std(thresVec.upper)'/sqrt(count.upper));
set(h1, 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'r', 'markersize', 10);
%set(h1(2), 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'r', 'markersize', 10);
%set(h1(3), 'color', 'k', 'linewidth', 2', 'marker', 'o', 'markerfacecolor', 'r', 'markersize', 10);
hold on
%h2 = plot(mean(thresVec.lower)');
h2 = errorbar([1:1:20], mean(thresVec.lower)', std(thresVec.lower)'/sqrt(count.lower));
set(h2, 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'g', 'markersize', 10);
%set(h2(2), 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'g', 'markersize', 10);
%set(h2(3), 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'g', 'markersize', 10);
set(gca, 'fontsize', 16);
hxlabel = xlabel('no. turnOver');
%hylabel = ylabel('SF (cpd)');
set(hxlabel, 'fontsize', 20);
%set(hylabel, 'fontsize', 20);



switch ExpInfo.Cfg.staircase.trialType
    case 'single'
        hylabel = ylabel('SF (cpd)');
        set(hylabel, 'fontsize', 20);
        axis([0 21 0 14]);
    case 'flanker'
        hylabel = ylabel('critical distance (deg.)');
        set(hylabel, 'fontsize', 20);
        axis([0 21 1 4]);
end

% figure;
% h1 = plot(thresVec.upper');
% %h1 = errorbar([1:1:20], mean(thresVec.upper)', std(thresVec.upper)'/sqrt(nBlocks/2));
% set(h1(1), 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'r', 'markersize', 10);
% set(h1(2), 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'r', 'markersize', 10);
% set(h1(3), 'color', 'k', 'linewidth', 2', 'marker', 'o', 'markerfacecolor', 'r', 'markersize', 10);
% hold on
% h2 = plot(thresVec.lower');
% %h2 = errorbar([1:1:20], mean(thresVec.lower)', std(thresVec.lower)'/sqrt(nBlocks/2));
% set(h2(1), 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'g', 'markersize', 10);
% set(h2(2), 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'g', 'markersize', 10);
% set(h2(3), 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'g', 'markersize', 10);
% set(gca, 'fontsize', 16);
% hxlabel = xlabel('no. turnOver');
% hylabel = ylabel('SF (cpd)');
% set(hxlabel, 'fontsize', 20);
% set(hylabel, 'fontsize', 20);


% 
% 
figure;
mat = [mean(thres.upper) mean(thres.lower)];
hbar = bar(mat);
set(hbar, 'facecolor', 'r', 'linewidth', 2, 'BarWidth', 0.6);
set(gca, 'fontsize', 16);
set(gca, 'xtick', [1:1:2]);
set(gca, 'xticklabel', {'upper VF'; 'lower VF'});
hxlabel = xlabel('position');
set(hxlabel, 'fontsize', 20);
set(gca, 'xticklabel', {sprintf('%02d deg above', abs(ExpInfo.Cfg.pos.targetEccYDeg)); sprintf('%02d deg below', abs(ExpInfo.Cfg.pos.targetEccYDeg))});

switch ExpInfo.Cfg.staircase.trialType
    case 'single'
        hylabel = ylabel('SF (cpd)');
        set(hylabel, 'fontsize', 20);
        axis([0.5 2.5 0 8]);
    case 'flanker'
        %set(gca, 'xticklabel', {sprintf('%02d deg above', abs(ExpInfo.Cfg.pos.targetEccYDeg)); sprintf('%02d deg below', abs(ExpInfo.Cfg.pos.targetEccYDeg))});
        hylabel = ylabel('critical distance (deg.)');
        set(hylabel, 'fontsize', 20);
        axis([0.5 2.5 0 3.5]);
end

%htext = text();

thresUpper = mean(thres.upper);
thresLower = mean(thres.lower);
%startValUpper = thresUpper/1.25;
%startValLower = thresLower/1.25;
startValUpper = thresUpper*0.75;
startValLower = thresLower*0.75;


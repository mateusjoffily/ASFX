function [r, t0] = fitLogFun(T, M)

%T=[11,15,18,23,26,31,39,44,54,64,74];
%M=[0.00476,0.0105,0.0207,0.0619,0.337,0.74,1.7,2.45,3.5,4.5,5.09];
%T = [0.04 0.08 0.16 0.32 0.64];
%M = [0.3846    0.2609    0.9286    0.9643    0.8929];
T=T';
M=M';
plot(T,M,'o')
title('Time evolution of algal sample.')
xlabel('Time (days)')
ylabel('Biomass (mm^2)')

%syms m r k t
%m=dsolve('Dm=r*m*(1-m/K)','t')

% 
% [m,n]=size(r);
% e=zeros(size(r));

%min=fminsearch(@myerror,[0.1;50],[],T,M);
min=fminsearch(@myerror,[0.04;0.64],[],T,M);
r=min(1);
t0=min(2);

H=1./(1+exp(-r*(T-t0)));

K=(H'*M)/(H'*H);

t=linspace(0.04, 0.64);
y=K./(1+exp(-r*(t-t0)));
%plot(T,M,'o',t,y)
plot(T,M,'o--',t,y)

title('Time evolution of algal sample.')
xlabel('Time (days)')
ylabel('Biomass (mm^2)')



function e=myerror(x,t,m)
r=x(1);
t0=x(2);
h=1./(1+exp(-r*(t-t0)));
e=m'*m-(h'*m)^2/(h'*h);
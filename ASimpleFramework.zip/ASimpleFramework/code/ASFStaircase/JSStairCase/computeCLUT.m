function [est, Lum, Int] = computeCLUT(fname)
%[est, CLUT] = computeCLUT('EyeMovementLabMattarello')
%load EyeMovementLabMattarello;
load(fname);
Lum = CIEcolour(4,:,3);
%Lum = CIEcolour(1,:,3); %green channel
Int = contrastLevels;

[est] = fitgammaAL(Lum, Int);

CLUT = [1:1:255].^(1/est);
%CLUT = CLUT/max(CLUT);
function analyzeCrowdingStaircaseEyeData(subNum, nBlocks, startBlock)
%analyzeCrowdingStaircaseEyeData(7, 10, 1)
%nBlocks = 10;
%startBlock = 1;
%blockVec = [startBlock:1:startBlock + nBlocks - 1];

%needs to be read in automatically
%screen.width = 1280;
%screen.height = 1024;

    for i = startBlock : startBlock + nBlocks - 1
        [trialinfo, eyedata]=develop(sprintf('C:\\applications\\Projects\\Angelika\\CrowdingStaircase\\data\\%02d_%02d.asc', subNum, i));
        save(sprintf('%02d_%02d_eye.mat', subNum, i), 'eyedata');
    end
    
    

function analyzeCrowdingStaircaseAcrossSubjects(subVec, nBlocks, startBlock, vertThresPix)
%example call: 
%analyzeCrowdingStaircaseAcrossSubjects([1:1:6], 10, 1, 25)
%analyzeCrowdingStaircaseAcrossSubjects([1:1:6], 10, 11, 25)
%
%analyzeCrowdingStaircaseAcrossSubjects([1 2 5 6 7 9 10 11], 10, 1, 50)
%analyzeCrowdingStaircaseAcrossSubjects([1 2 5 6 7 9 10 11], 10, 11, 50)
%
%GROUP A (same effects for single and flanked targets)
%analyzeCrowdingStaircaseAcrossSubjects([1 2 7 9], 10, 1, 50)
%analyzeCrowdingStaircaseAcrossSubjects([1 2 7 9], 10, 11, 50)
%
%GROUP B (opposite effects for single and flanked targets)
%analyzeCrowdingStaircaseAcrossSubjects([5 6 10 11], 10, 1, 50)
%analyzeCrowdingStaircaseAcrossSubjects([5 6 10 11], 10, 11, 50)
%
%nBlocks = 6;
%subject = 7;
%subject = 4;
%thres.upper = zeros(nBlocks/2, 1);
%thres.lower = zeros(nBlocks/2, 1);
count.upper = 0;
count.lower = 0;
count.subject = 0;
%nSubjects = 6;
nSubjects = length(subVec);

for i =  1 : length(subVec)
    subject = subVec(i);
    %for subject = 1 : nSubjects
    %for i = 1 : nBlocks;
    if subject == 1
        %check if there exist eye movement data for this participant
        %at the moment we only have six blocks from participant 1
        if exist(sprintf('%02d_%02d_eye.mat', subject, 1));
            [validBlockVec, nValidBlocks] = evalVertEyePos(subject, vertThresPix, 6, startBlock);
           
            disp(sprintf('using %d out of %d blocks for participant %02d', nValidBlocks, 6, subject));
            
            
        else
            validBlockVec = [startBlock:1:startBlock + nBlocks - 1];
            disp(sprintf('warning: no eye movement data available for participant %02d', subject));
            disp(sprintf('using %d out of %d blocks for participant %02d', 6, 6, subject));
        end
    else

        %check if there exist eye movement data for this participant
        if exist(sprintf('%02d_%02d_eye.mat', subject, 1));
            [validBlockVec, nValidBlocks] = evalVertEyePos(subject, vertThresPix, nBlocks, startBlock);
            
            
            
            
            disp(sprintf('using %d out of %d blocks for participant %02d', nValidBlocks, nBlocks, subject));
        else
            validBlockVec = [startBlock:1:startBlock + nBlocks - 1];
            disp(sprintf('warning: no eye movement data available for participant %02d', subject));
            disp(sprintf('using %d out of %d blocks for participant %02d', nBlocks, nBlocks, subject));
        end
    end

    %------------------------------------------------
    if subject == 2
        t = 1;
    else
        %--------------------------------------------------------------
            %if exptype is flanker, validBlockVec starts with startBlock instead of 1!
            %read in first block that is contained in validBlockVec and check for trial
            %type; adjust validBlockVec for trialType flanker
            load (sprintf('%02d_%02d.mat', subject, startBlock));
            switch ExpInfo.Cfg.staircase.trialType
                case 'flanker'
                    validBlockVec = validBlockVec + startBlock -1;
            end
            %--------------------------------------------------------------
    end
    %------------------------------------------------
    
    count.subject = count.subject + 1;

    %for i = startBlock : startBlock +nBlocks -1;
    
    

    for j = 1 : length(validBlockVec)
        thisBlock = validBlockVec(j);
        %count.block = count.block + 1;
        load (sprintf('%02d_%02d.mat', subject, thisBlock));
        if ExpInfo.Cfg.pos.targetEccYDeg < 0
            count.upper = count.upper + 1;
            switch ExpInfo.Cfg.staircase.trialType
                case 'single'
                    thres.upper (count.upper)      = mean(ExpInfo.TrialInfo(2).trial.thresVecCPD(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                    thresVec.upper(count.upper, :) = ExpInfo.TrialInfo(2).trial.thresVecCPD;


                case 'flanker'
                    %thres.upper (count.upper)      = mean(ExpInfo.TrialInfo(2).trial.thresDeg(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                    %thresVec.upper(count.upper, :) = ExpInfo.TrialInfo(2).trial.thresDeg;
                    thres.upper (count.upper)      = mean(ExpInfo.TrialInfo(2).trial.thresVecDeg(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                    thresVec.upper(count.upper, :) = ExpInfo.TrialInfo(2).trial.thresVecDeg;
            end
        else
            if ExpInfo.Cfg.pos.targetEccYDeg > 0
                count.lower = count.lower + 1;
                switch ExpInfo.Cfg.staircase.trialType
                    case 'single'
                        thres.lower (count.lower)      = mean(ExpInfo.TrialInfo(2).trial.thresVecCPD(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                        thresVec.lower(count.lower, :) = ExpInfo.TrialInfo(2).trial.thresVecCPD;
                    case 'flanker'
                        %thres.lower (count.lower)      = mean(ExpInfo.TrialInfo(2).trial.thresDeg(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                        %thresVec.lower(count.lower, :) = ExpInfo.TrialInfo(2).trial.thresDeg;
                        thres.lower(count.lower)       = mean(ExpInfo.TrialInfo(2).trial.thresVecDeg(ExpInfo.Cfg.staircase.nSkipTurnOvers+1 : end));
                        thresVec.lower(count.lower, :) = ExpInfo.TrialInfo(2).trial.thresVecDeg;

                end
            end
        end
    end
    meanThresVec.upper(count.subject, :) = mean(thresVec.upper);
    meanThresVec.lower(count.subject, :) = mean(thresVec.lower);
    meanThres.upper(count.subject, :)    = mean(thres.upper);
    meanThres.lower(count.subject, :)    = mean(thres.lower);


end

%----------------------------------------------



figure;
%h1 = errorbar([1:1:20], mean(meanThresVec.upper)', (std(meanThresVec.upper)'/sqrt(nSubjects)));
h1 = errorbar([1:1:20], mean(meanThresVec.upper)', (std(meanThresVec.upper)'/sqrt(nSubjects))*1.96);
set(h1, 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'r', 'markersize', 10);
hold on
%h2 = errorbar([1:1:20], mean(meanThresVec.lower)', (std(meanThresVec.lower)'/sqrt(nSubjects)));
h2 = errorbar([1:1:20], mean(meanThresVec.lower)', (std(meanThresVec.lower)'/sqrt(nSubjects))*1.96);
set(h2, 'color', 'k', 'linewidth', 2, 'marker', 'o', 'markerfacecolor', 'g', 'markersize', 10);
set(gca, 'fontsize', 16);
hxlabel = xlabel('no. turnOver');
set(hxlabel, 'fontsize', 20);

hleg = legend([h1, h2],'upper VF', 'lower VF');  
set(hleg, 'fontsize', 20, 'box', 'off');

switch ExpInfo.Cfg.staircase.trialType
    case 'single'
        hylabel = ylabel('SF (cpd)');
        set(hylabel, 'fontsize', 20);
        axis([0 21 0 14]);
    case 'flanker'
        hylabel = ylabel('critical distance (deg.)');
        set(hylabel, 'fontsize', 20);
        axis([0 21 1 4]);
end


figure;
%h1 = errorbar([1 2], [mean(meanThres.upper) mean(meanThres.lower)], [(std(meanThres.upper)/sqrt(nSubjects)) (std(meanThres.lower)/sqrt(nSubjects))]);
h1 = errorbar([1 2], [mean(meanThres.upper) mean(meanThres.lower)], [(std(meanThres.upper)/sqrt(nSubjects))*1.96 (std(meanThres.lower)/sqrt(nSubjects))*1.96]);
set(h1, 'color', 'k', 'linewidth', 2);
set(gca, 'fontsize', 16);
set(gca, 'xtick', [1:1:2]);
set(gca, 'xticklabel', {'upper VF'; 'lower VF'});
hxlabel = xlabel('position');
set(hxlabel, 'fontsize', 20);

switch ExpInfo.Cfg.staircase.trialType
    case 'single'
        hylabel = ylabel('SF (cpd)');
        set(hylabel, 'fontsize', 20);
        axis([0.5 2.5 0 8]);
    case 'flanker'
        hylabel = ylabel('critical distance (deg.)');
        set(hylabel, 'fontsize', 20);
        axis([0.5 2.5 0 3.5]);
end

t=1;

[H,P,CI,STATS] = ttest(meanThres.upper, meanThres.lower);
disp(sprintf('t(%d) = %2.2f, p = %1.4f', STATS.df, STATS.tstat, P));
disp(sprintf('mean Upper: %2.2f, mean Lower: %2.2f', mean(meanThres.upper), mean(meanThres.lower)));
% %htext = text();
% 
% thresUpper = mean(thres.upper);
% thresLower = mean(thres.lower);
% %startValUpper = thresUpper/1.25;
% %startValLower = thresLower/1.25;
% startValUpper = thresUpper*0.75;
% startValLower = thresLower*0.75;

%---------------------------
%group A
GroupA.SFUpper = 5.4;
GroupA.SFLower = 6.5;
GroupA.CDUpper = 3.03;
GroupA.CDLower = 2.02;

%group B
GroupB.SFUpper = 6.1;
GroupB.SFLower = 7.35;
GroupB.CDUpper = 1.99;
GroupB.CDLower = 2.48;

figure;
mat = [GroupA.SFUpper GroupA.SFLower; GroupB.SFUpper GroupB.SFLower];
bar(mat);
axis([0.5 2.5 0 8]);

figure;
mat = [GroupA.CDUpper GroupA.CDLower; GroupB.CDUpper GroupB.CDLower];
bar(mat);
axis([0.5 2.5 0 4]);


function create_trialdef_CrowdingStaircase(subject, session, Cfg)
%---------------------------------------
%created 03-2009 angelika.lingnau@unitn.it
%last change: 2009-03-11 AL

%[Cfg.nPos, dummy] = size(Cfg.tPos);
%[nPrintSizes, dummy] = size(Cfg.printSizePixel);


nTrials = 1;

%condMat = [1  0  1  2  Cfg.targetDurationFrames  2   Cfg.responseDurationFrames  Cfg.TargetOnPage  0];
condMat = [1  0  2  2  Cfg.dur.prePeriodDurationFrames  2  Cfg.dur.targetDurationFrames  2   Cfg.dur.responseDurationFrames  Cfg.TargetOnPage  0];
  
filename = sprintf('%02d_%02d.trd', subject, session);

%----------CHECK FOR EXISTENCE OF OUTPUT FILE
if exist(filename) == 2
    msg = sprintf('File %s already exists. Overwrite?', filename);
    ButtonName=questdlg(msg, 'Warning', 'Yes','No','No');
    if strcmp(ButtonName, 'No')
        trialdef = [];
        return
    end
end

fid = fopen(filename, 'w');
if ~fid
    fid = 1;
end

fprintf(fid, '%3d\n', nTrials); %first row of TDEF contains code vector
fprintf(fid, ' 99  0  0  1  75  2  75  2  1\n'); %second row contains warmup page

fprintf(fid, '%3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d\n', condMat);
fprintf(fid, ' 99  0  0  1  75  1  75  1  1\n'); %last row contains cooldown page
fclose(fid);
t=1;



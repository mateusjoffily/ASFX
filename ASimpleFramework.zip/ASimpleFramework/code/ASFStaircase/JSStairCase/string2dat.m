function [out]=string2dat(event_type, file)
%GET DISPLAY START

[nlines, dummy]=size(file);
count = 0;
for i = 1:nlines
    if findstr(file{i}, event_type)
        count = count + 1;
        cases(count) = i;
    end
end



ntrials = count;

if ntrials==0
    out=[];
    
else

    event = file(cases);
    event = char(event);

    %CONVERT STRINGS INTO DATA VECTORS
    %SAVE IN A TEXT FILE
    fid = fopen('temp.txt', 'w');
    for i = 1:ntrials
        temp = event(i,:);
        temp_char = char(temp);
        fprintf(fid, '%s', temp_char);
        fprintf(fid, '\n');
    end
    fclose(fid);

    %READ TEXT FILE
    switch event_type
        case {'TRIALSTART'}
            %disp('find DISPLAY ON');
            %[dummy1, out, dummy2, dummy3, dummy4] = textread('temp.txt', '%s %d %d %s %s');
            [dummy1, out, dummy2] = textread('temp.txt', '%s %d %s');
        case {'TRIALEND'}
            %disp('find DISPLAY ON');
            %[dummy1, out, dummy2, dummy3, dummy4] = textread('temp.txt', '%s %d %d %s %s');
            [dummy1, out, dummy2] = textread('temp.txt', '%s %d %s');
        case {'DISPLAY ON'}
            %disp('find DISPLAY ON');
            %[dummy1, out, dummy2, dummy3, dummy4] = textread('temp.txt', '%s %d %d %s %s');
            [dummy1, out, dummy2, dummy3] = textread('temp.txt', '%s %d %s %s');
        case {'TIMEOUT'}
            %disp('find END');
            %MSG	5816956 TIMEOUT
            [dummy1, out, dummy2] = textread('temp.txt', '%s %d %s');
        case {'END'}
            %disp('find END');
            [dummy1, out, dummy2, dummy3, dummy4, dummy5, dummy6] = textread('temp.txt', '%s %d %s %s %s %f %f');
        case {'DRIFTCORRECT L LEFT'}
            %disp('find DC left');
            [d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, out.x, out.y, d13] = textread('temp.txt', '%s %d %s %s %s %s %d ,%d %s %f %s %f ,%f %s');
        case {'DRIFTCORRECT R RIGHT'}
            %disp('find DC right');
            [d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, out.x, out.y, d13] = textread('temp.txt', '%s %d %s %s %s %s %d ,%d %s %f %s %f ,%f %s');
        case {'TRIAL_ID'} %MSG	6253185 TRIAL_ID 8
            %disp('find start and end of fixation');
            %[dummy1, dummy2, dummy3, out] = textread('temp.txt', '%s %d %s %d');
            [dummy1, dummy2, dummy3, dummy4, out] = textread('temp.txt', '%s %d %s %d %d');
        case {'EFIX'}
            %disp('find start and end of fixation');
            [dummy1, dummy2, out.start, out.end, out.dur, out.x, out.y, dummy3] = textread('temp.txt', '%s %s %d %d %d %f %f %d');
            t=1;
        case {'ESACC'}
            %disp('find start and end of saccade');
            [d1, d2, out.start_t, out.end_t, out.dur, out.x0, out.y0, out.x1, out.y1, out.amplitude, out.peak_vel] = textread('temp.txt', '%s %s %d %d %d %f %f %f %f %f %f');
        case {'   .	   9999	   9999	   9999	   9999	   9999'}
            [d1, d2, d3, d4, d5, d6] = textread('temp.txt', '%s %d %d %d %d %d %d');

        otherwise
            disp(sprintf('Warning: %s not found in ASC file.'), event_type);
    end
    
end
if ntrials>0
    delete('temp.txt'); %DELETE TEXT FILE
end
%BELOW
figure;
load 03_02.mat
plot(ExpInfo.TrialInfo(2).trial.thresVec,'g-o')
thres(1)=ExpInfo.TrialInfo(2).trial.thres;
hold on
load 03_03.mat
plot(ExpInfo.TrialInfo(2).trial.thresVec,'g--o')
thres(2)=ExpInfo.TrialInfo(2).trial.thres;
load 03_06.mat
plot(ExpInfo.TrialInfo(2).trial.thresVec,'g:o')
thres(3)=ExpInfo.TrialInfo(2).trial.thres;


%ABOVE
%figure;
load 03_01.mat
plot(ExpInfo.TrialInfo(2).trial.thresVec,'r-o')
thres(4)=ExpInfo.TrialInfo(2).trial.thres;
hold on
load 03_04.mat
plot(ExpInfo.TrialInfo(2).trial.thresVec,'r--o')
thres(5)=ExpInfo.TrialInfo(2).trial.thres;
load 03_05.mat
plot(ExpInfo.TrialInfo(2).trial.thresVec,'r:o')
thres(6)=ExpInfo.TrialInfo(2).trial.thres;
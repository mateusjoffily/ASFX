function ExpInfo = staircase_run(subject, session, Cfg)
%function ExpInfo = staircase_run(subject, session, Cfg)
%----------------------------------------------------
%created 03/2009 angelika.lingnau@unitn.it
%generalization 6/2009 jens.schwarzbach@unitn.it
%last change:
%----------------------------------------------------
%% Example call:
% Cfg.StairCase.trialFunction = @ASFShowTrial_Staircase_Sound;
% ExpInfo = staircase_run(4, 1, Cfg)


%----------------------------------------------------
%EYETRACKING STUFF
Cfg.Eyetracking.useEyelink = 0;
Cfg.Eyetracking.useEyelinkMouseMode = 0;
Cfg.Eyetracking.doCalibration = 0;
Cfg.Eyetracking.doDriftCorr=0;
Cfg.Eyetracking.largeCalibTargets = 0;

%----------------------------------------------------
%SCREEN STUFF
%SCREEN EYE TRACKING LAB
% Cfg.Screen.Resolution.width = 1280;
% Cfg.Screen.Resolution.height = 1024;
% Cfg.Screen.distanceCm = 80;
% Cfg.Screen.xDimCm = 39.5;
% Cfg.Screen.yDimCm = 29;

%LARGE SCREEN JS
Cfg.Screen.Resolution.width = 1920;%1280;%1650; %% %FRANCESCA, please check if this is the resolution we are currently using (I'm pretty sure)
Cfg.Screen.Resolution.height = 1200;%1024;%1050; ;%%FRANCESCA, please check if this is the resolution we are currently using (I'm pretty sure)
Cfg.Screen.distanceCm = 80;%was 80% 135
Cfg.Screen.xDimCm = 51.5;
Cfg.Screen.yDimCm = 32.5;
%Cfg.Screen.rect = [1, 1, 200, 320];




Cfg.Screen.color = [255/2, 255/2, 255/2];
Cfg.Screen.rect = [];


%Cfg.timeout = 1;                     %How many seconds are available for responding at the end of a mini block? FRANCESCA, please try out if this is long enough. Feel free to adjust.
%----------------------------------------------------
%DURATION STUFF
Cfg.StairCase.Stimulation.targetDurationFrames = 5; %[9]; %with 75 Hz, this corresponds to an exposure duration of 120 ms
Cfg.StairCase.Stimulation.responseDurationFrames = 120; %with 75 Hz, this corresponds to a response duration (after each triplet) of 1600 ms
Cfg.StairCase.Stimulation.prePeriodDurationFrames = 12; %200 ms
Cfg.StairCase.Stimulation.sndTarget1 = MakeBeep(500, 0.1);
Cfg.StairCase.Stimulation.sndTarget2 = MakeBeep(1000, 0.1);


%----------------------------------------------------
%STAIRCASE STUFF
Cfg.StairCase.nTurnOvers = 20;
Cfg.StairCase.nSkipTurnOvers = 3;
Cfg.StairCase.nDown = 2; %choose lower intensity value (more difficult) after two correct trials
Cfg.StairCase.nUp = 1;% %choose higher intensity value (easier) after one mistake
Cfg.StairCase.ratioOfCurrentLevelUp = 0.1;  %easier
Cfg.StairCase.ratioOfCurrentLevelDown = 0.05; %more difficult
Cfg.StairCase.maxTrials = 100;
%Cfg.StairCase.trialType = trialType;
%Cfg.StairCase.currentLevelDeg = 2; %start value for flanker task

%----------------------------------------------------
%MIXED
Cfg.responseTerminatesTrial = 0;
Cfg.feedbackTrialCorrect = 0;
Cfg.feedbackTrialError = 0;

%Cfg.size.Fix = 40;
Cfg.TargetOnPage = 2;%1

Cfg.userSuppliedTrialFunction = @ASFStaircase;
Cfg.userDefinedSTMcolumns = 1;
Cfg.StairCase.currentLevel = 10; %this is the start level (between 0 and 100)

staircase_create_trialdef(subject, session, Cfg);

stdName = 'stimdef.std';
trdName = sprintf('%02d_%02d.trd', subject, session);
sName = sprintf('%02d_%02d', subject, session);
[ExpInfo] = ASF(stdName, trdName, sName, Cfg);

figure
subplot(1, 2, 1)
plot(1:ExpInfo.Cfg.StairCase.maxTrials, ExpInfo.TrialInfo(2).trial.currentLevelVec, 'o-', 'Color', 'k')
hold on
casesCorrect = find(ExpInfo.TrialInfo(2).trial.evalVec == 1);
ph_c = plot(casesCorrect, ExpInfo.TrialInfo(2).trial.currentLevelVec(casesCorrect), 'o');
set(ph_c, 'MarkerEdgeColor', 'g', 'MarkerFaceColor', 'g')
casesErr = find(ExpInfo.TrialInfo(2).trial.evalVec == -1);
ph_e = plot(casesErr, ExpInfo.TrialInfo(2).trial.currentLevelVec(casesErr), 'o');
set(ph_e, 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r')
cases = find(~isnan(ExpInfo.TrialInfo(2).trial.reversalVec) & (ExpInfo.TrialInfo(2).trial.reversalVec ~=0));
ph_r = plot(cases, ExpInfo.TrialInfo(2).trial.currentLevelVec(cases), 'ok', 'LineWidth', 2);
hold off
xlabel('Trial Number')
ylabel('Stimulus Intensity')
set(gca, 'xlim', [1, ExpInfo.Cfg.StairCase.maxTrials])
box off

subplot(1, 2, 2)
bar(ExpInfo.TrialInfo(2).trial.changeVec)
set(gca, 'ylim', [-1, 1], 'xlim', [1, ExpInfo.Cfg.StairCase.maxTrials])
xlabel('Trial Number')
ylabel('LOWER <-   Intensity Change   -> HIGHER')
box off

if length(ExpInfo.TrialInfo(2).trial.reversals)>ExpInfo.Cfg.StairCase.nSkipTurnOvers
    validReversalLevels = ExpInfo.TrialInfo(2).trial.currentLevelVec(ExpInfo.TrialInfo(2).trial.reversals(ExpInfo.Cfg.StairCase.nSkipTurnOvers+1:end)); 
    thresh = mean(validReversalLevels);
    threshSd = std(validReversalLevels);
else
    thresh = [];
    threshSd = [];
end
fprintf(1, 'Threshold: %6.3f, n: %d, SD: %6.3f, SE: %6.3f\n', thresh, length(validReversalLevels), threshSd, threshSd/sqrt(length(validReversalLevels)))


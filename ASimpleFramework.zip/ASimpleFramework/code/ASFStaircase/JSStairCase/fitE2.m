function [b,r] = fitE2


X = [2 4 6]';
%y = [0.18 0.3 0.6]';lower?
y = [0.1 0.22 0.26]';%upper?
%beta0 = [1 1 1]';
beta0 = [1]';
[b,r,J,COVB,mse] = nlinfit(X,y,@myFitE2,beta0);
%nlintool(X,y,@myFitE2,beta0)
t = 1;

function y = myFitE2(beta, x)
%example call: 
% The model form is:

x1 = 0.07;
b = beta;
%x1 = x(:,1);
x2 = x(:,1);

y = x1*(1 + (x2./b));

t=1;

function [intMin] = getIntensityFromContrast(intMax, MichelsonContrast)
%[intMin] = getIntensityFromContrast(255/2, 0.12)
[est, Lum, Int] = computeCLUT('EyeMovementLabMattarello');
%[est, Lum, Int] = computeCLUT('LaptopAngelika_20081121');

close all;
%intMax = 255/2;
%MichelsonContrast = contrast;%desired contrast
%MichelsonContrast = 0.12;%desired contrast

intMin = intMax * (1-MichelsonContrast)/(MichelsonContrast+1); %luminance value to choose
%lumMin = lumMax * (1-MichelsonContrast)/(MichelsonContrast+1); %luminance value to choose

figure;
CLUT = Int.^(1/est)/max(Int.^(1/est));
CLUTcorrected = Lum.^(1/est);
CLUTcorrected = CLUTcorrected/max(CLUTcorrected);
hpatch = patch([intMin intMax intMax intMin intMin], [0.001 0.001 0.999 0.999 0.001], [0.9 0.9 0.9]);
set(hpatch, 'edgecolor', [0.9 0.9 0.9]);
hold on;
h1=plot(Int*2.25, Lum/max(Lum), 'r');
h2=plot(Int*2.25, CLUT, 'k');
h3=plot(Int*2.25, CLUTcorrected, 'g');
set(h1, 'linewidth', 3);
set(h2, 'linewidth', 3);
set(h3, 'linewidth', 3);
set(gca, 'fontsize', 20);
xlab=xlabel('Intensity');
ylab=ylabel('Luminance (normalized)');
set(xlab, 'fontsize', 24);
set(ylab, 'fontsize', 24);
%figure;
hpatch1 = patch([180 220 220 180 180], [0.1 0.1 0.3 0.3 0.1], [intMax/255 intMax/255 intMax/255]);
set(hpatch1, 'edgecolor', [intMax/255 intMax/255 intMax/255]);
htext = text(185, 0.2, 'X');
set(htext, 'color', [intMin/255 intMin/255 intMin/255], 'fontsize', 60);
axis([0 255 0 1]);
htit = title(sprintf('%2d %% contrast', MichelsonContrast*100));
set(htit, 'fontsize', 20);
%set(gca, 'xtick', [], 'ytick', []);
%hpatch2 = patch([2 3 3 2 2], [1 1 2 2 1], [intMax/255 intMax/255 intMax/255]);
%axis([0 3 0 2]);
%lumMax = 255/2;
%lumMin = 100;
%lumMax = lumMax.^(1/est);
%lumMin = lumMin.^(1/est);

%lumMax = 4.19;
%lumMin = 3.31;
%MichelsonContrast = (lumMax - lumMin)/(lumMax + lumMin);

%CLUT = [1:1:255].^(1/est)
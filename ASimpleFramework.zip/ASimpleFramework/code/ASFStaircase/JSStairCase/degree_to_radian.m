%degree_to_radian

function radian = degree_to_radian(angles)
 
radian=(angles*pi)./180;
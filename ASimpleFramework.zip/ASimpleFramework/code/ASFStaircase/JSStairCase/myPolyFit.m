function myPolyFit

thresh = 0.75; %get me the print size that leads to 0.75% performance

N = 2;
x = [0.04 0.08 0.16 0.32 0.64];
%y1 = [0.4167 0.5833 0.9167 1.0000 1.0000];
%xLog2 = log2(x);
y1 = [0.3846    0.2609    0.9286    0.9643    0.8929];
%y1Log2 = log2(y1);

%[x,fval,exitflag,output] = fminsearch(@log,x);



[p, s]=polyfit(x, y1, N);
y1Est=polyval(p, x);

% if N==2
%     F = @(x)p(1)*x + p(2);
% else if N==3
%         F = @(x)p(1)*x.^2 + p(2)*x + p(3);
%     else if N==5
%             F = @(x)p(1)*x.^5 + p(2)*x.^4 + p(3)*x.^3 + p(4)*x.^2 + p(5)*x + p(6);
%         end
%     end
% end
% 
;
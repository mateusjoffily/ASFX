function drawToScreen(subject, Cfg)
%draws targets to background image and saves as BMP
%last change: 2008-07-11 AL
%-------------------------------
expName = 'test';
%--------------------------------

%[dummy, Cfg.size.Fix]=calc_size_from_angle(1, Cfg.Screen.distanceCm, Cfg.Screen.Resolution.width/Cfg.Screen.xDimCm);
%Cfg.size.Fix = 40;
%Cfg.x0 = Cfg.fixCentre(1);
%Cfg.pos.y0 = Cfg.fixCentre(2);
%Cfg.rectSizePixel = 111;%corresponds to 5� if distance eye screen is 40 cm
[windowPtr, Cfg] = InitScreen (Cfg, expName);
%--------------------------------

%for i=3
for i=1:2
    draw_single_stim(i, Cfg, windowPtr);
end

close all;
clear all;

function draw_single_stim(stimNum, Cfg, windowPtr)

switch stimNum
    case 1 %empty
        imageArray=Screen('GetImage', windowPtr);
        imwrite(imageArray,'.\imagesCrowdingEccentricity\01 empty.bmp');
    
    case 2 %fixation black
        Screen('DrawLine', windowPtr, [0 0 0], Cfg.pos.x0 - Cfg.size.Fix/2, Cfg.pos.y0,  Cfg.pos.x0 + Cfg.size.Fix/2, Cfg.pos.y0, 4);
        Screen('DrawLine', windowPtr, [0 0 0], Cfg.pos.x0, Cfg.pos.y0  - Cfg.size.Fix/2,  Cfg.pos.x0, Cfg.pos.y0 +  Cfg.size.Fix/2, 4);
        Screen('Flip', windowPtr);
        imageArray=Screen('GetImage', windowPtr);
        imwrite(imageArray,'.\imagesCrowdingEccentricity\02 fixation black.bmp');
        Screen('FillRect', windowPtr, Cfg.Screen.color);

    case 3 %fixation green
        %Screen('DrawLine', windowPtr, [0 200 0], Cfg.pos.x0 - Cfg.size.Fix/2, Cfg.pos.y0,  Cfg.pos.x0 + Cfg.size.Fix/2, Cfg.pos.y0, 4);
        %Screen('DrawLine', windowPtr, [0 200 0], Cfg.pos.x0, Cfg.pos.y0  - Cfg.size.Fix/2,  Cfg.pos.x0, Cfg.pos.y0 +  Cfg.size.Fix/2, 4);
        %Screen('DrawLine', windowPtr, [0 125 0], Cfg.pos.x0 - Cfg.size.Fix/2, Cfg.pos.y0,  Cfg.pos.x0 + Cfg.size.Fix/2, Cfg.pos.y0, 4); %luminance: 9.33 (equal to mean gray; eyetracker screen)
        %Screen('DrawLine', windowPtr, [0 125 0], Cfg.pos.x0, Cfg.pos.y0  - Cfg.size.Fix/2,  Cfg.pos.x0, Cfg.pos.y0 +  Cfg.size.Fix/2, 4);%luminance: 9.33 (equal to mean gray; eyetracker screen)
        Screen('gluDisk', windowPtr, [0 125 0], Cfg.pos.x0, Cfg.pos.y0, Cfg.size.Fix/2);
        
        Screen('Flip', windowPtr);
        imageArray=Screen('GetImage', windowPtr);
        imwrite(imageArray,'.\imagesCrowdingEccentricity\03 fixation green.bmp');
        Screen('FillRect', windowPtr, Cfg.Screen.color);
        
    case 4 %fixation red
        %Screen('DrawLine', windowPtr, [109 0 0], Cfg.pos.x0 - Cfg.size.Fix/2, Cfg.pos.y0,  Cfg.pos.x0 + Cfg.size.Fix/2, Cfg.pos.y0, 4); %luminance: 9.34 (equal to mean gray; eyetracker screen)
        %Screen('DrawLine', windowPtr, [109 0 0], Cfg.pos.x0, Cfg.pos.y0  - Cfg.size.Fix/2,  Cfg.pos.x0, Cfg.pos.y0 +  Cfg.size.Fix/2, 4);%luminance: 9.34 (equal to mean gray; eyetracker screen)
        Screen('gluDisk', windowPtr, [109 0 0], Cfg.pos.x0, Cfg.pos.y0, Cfg.size.Fix/2);
        Screen('Flip', windowPtr);
        imageArray=Screen('GetImage', windowPtr);
        imwrite(imageArray,'.\imagesCrowdingEccentricity\04 fixation red.bmp');
        Screen('FillRect', windowPtr, Cfg.Screen.color);

    case 5 %letters
        [bbox] = MyDrawCenteredText(windowPtr, 'xxx', [0 0 0], Cfg.pos.x0, Cfg.pos.y0, 100);
        
end


%-----------------------------------------------------
function [windowPtr, Cfg] = InitScreen (Cfg, expName)

%function [windowPtr, Cfg] = PTBInit(Cfg, expName)
if(~isfield(Cfg, 'Screen')), Cfg.Screen = []; end
if(~isfield(Cfg.Screen, 'color')), Cfg.Screen.color = [255, 255, 255]; end %OBSOLETE BUT I'LL LEAVEIT FOR NOW
%if(~isfield(Cfg.Screen, 'color')), Cfg.Screen.color = Cfg.bgrCol; end %OBSOLETE BUT I'LL LEAVEIT FOR NOW
if(~isfield(Cfg.Screen, 'rect')), Cfg.Screen.rect = []; end
if(~isfield(Cfg.Screen, 'pixelSize')), Cfg.Screen.pixelSize = []; end
if(~isfield(Cfg.Screen, 'numberOfBuffers')), Cfg.Screen.numberOfBuffers = []; end
if(~isfield(Cfg.Screen, 'stereomode')), Cfg.Screen.stereomode = []; end
if(~isfield(Cfg.Screen, 'multisample')), Cfg.Screen.multisample = []; end
if(~isfield(Cfg.Screen, 'DefaultFontSize')), Cfg.Screen.defaultFontSize = 36; end
if(~isfield(Cfg.Screen, 'DefaultTextColor')), Cfg.Screen.defaultTextColor = [255, 0, 0]; end
if(~isfield(Cfg.Screen, 'xDimCm')), Cfg.Screen.xDimCm = 33; end %DELL M70
if(~isfield(Cfg.Screen, 'yDimCm')), Cfg.Screen.yDimCm = 20.625; end %DELL M70
if(~isfield(Cfg.Screen, 'distanceCm')), Cfg.Screen.distanceCm = 45; end %DELL M70


windowPtr = [];
%CHECK WHETHER DATA FILE ALREADY EXISTS
[Cfg.pathstr, Cfg.name, Cfg.ext, Cfg.version] = fileparts(expName);
filename = fullfile(Cfg.pathstr, [Cfg.name, '.mat']);
if exist(filename, 'file') == 2
    msg = sprintf('File %s already exists. Overwrite?', filename);
    ButtonName = questdlg(msg, 'Warning', 'Yes','No','No');
    if strcmp(ButtonName, 'No')
        %trialdef = [];
        return
    end
end

% get screen
screens = Screen('Screens'); %RETURNS A LIST OF AVAIALBLE DISPLAYS
screenNumber = max(screens); %#ok<NASGU> %PICK THE ONE WITH THE HIGEST NUMBER
if length(screens) > 1
    screenNumber = screens(end);
else
    screenNumber = 0;
end

HideCursor;

% Open a double buffered fullscreen window and draw a gray background to front and back buffers:
fprintf(1, '*****************************************************************************\n'); 
fprintf(1, '********** OPENING ONSCREEN WINDOW AND PERFORMING SOME DIAGNOSTICS **********\n');
fprintf(1, '*****************************************************************************\n'); 
[windowPtr, Cfg.Screen.rect] = Screen('OpenWindow', screenNumber, Cfg.Screen.color, Cfg.Screen.rect, Cfg.Screen.pixelSize, Cfg.Screen.numberOfBuffers);
%SOME GRAPHICS BOARDS SEEM NOT TO LIKE THIS
%[oldmaximumvalue oldclampcolors] = Screen('ColorRange', windowPtr)
fprintf(1, '*****************************************************************************\n'); 
fprintf(1, '********** DIAGNOSTICS COMPLETED                                   **********\n')
fprintf(1, '*****************************************************************************\n'); 

Cfg.FrameRate = Screen('NominalFrameRate', windowPtr);
[Cfg.MonitorFlipInterval, Cfg.GetFlipInterval.nrValidSamples, Cfg.GetFlipInterval.stddev ] = Screen('GetFlipInterval', windowPtr );
[Cfg.Screen.width, Cfg.Screen.height] = Screen('WindowSize', windowPtr);
Cfg.Environment.computer = Screen('Computer');
Cfg.Environment.version = Screen('Version');

%CENTER OF THE SCREEN
Cfg.Screen.centerX = Cfg.Screen.width/2;
Cfg.Screen.centerY = Cfg.Screen.height/2;


%DEG VISUAL ANGLE FOR SCREEN
Cfg.Screen.visualAngleDegX = atan(Cfg.Screen.xDimCm/(2*Cfg.Screen.distanceCm))/pi*180*2;
Cfg.Screen.visualAngleDegY = atan(Cfg.Screen.yDimCm/(2*Cfg.Screen.distanceCm))/pi*180*2;
%DEG VISUAL ANGLE PER PIXEL
Cfg.Screen.visualAngleDegPerPixelX = Cfg.Screen.visualAngleDegX/Cfg.Screen.width;
Cfg.Screen.visualAngleDegPerPixelY = Cfg.Screen.visualAngleDegY/Cfg.Screen.height;
Cfg.Screen.visualAnglePixelPerDegX = Cfg.Screen.width/Cfg.Screen.visualAngleDegX;
Cfg.Screen.visualAnglePixelPerDegY = Cfg.Screen.height/Cfg.Screen.visualAngleDegY;

fprintf(1, 'Screen Parameters:\n');
fprintf(1, ' Width: %5.3f cm, %5d pixels, %5.3f deg [%5.3f deg/pix, %5.3f pix/deg]\n', Cfg.Screen.xDimCm, Cfg.Screen.width, Cfg.Screen.visualAngleDegX, Cfg.Screen.visualAngleDegPerPixelX, Cfg.Screen.visualAnglePixelPerDegX);
fprintf(1, 'Height: %5.3f cm, %5d pixels, %5.3f deg [%5.3f deg/pix, %5.3f pix/deg]\n', Cfg.Screen.yDimCm, Cfg.Screen.height, Cfg.Screen.visualAngleDegY, Cfg.Screen.visualAngleDegPerPixelY, Cfg.Screen.visualAnglePixelPerDegY);
%pause



%DEFAULT TEXT SIZE
Screen('TextSize', windowPtr, Cfg.Screen.defaultFontSize);


% returns as default the mean gray value of screen
% gray = GrayIndex(screenNumber);
% white = WhiteIndex(screenNumber);
% black = BlackIndex(screenNumber);

Screen('TextColor', windowPtr, Cfg.Screen.defaultTextColor);

Screen('FillRect', windowPtr, Cfg.Screen.color);
Screen('Flip', windowPtr);

% set priority
priorityLevel = MaxPriority(windowPtr);
Priority(priorityLevel);

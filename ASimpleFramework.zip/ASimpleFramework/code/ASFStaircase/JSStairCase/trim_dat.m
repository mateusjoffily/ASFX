function [data_trimmed]=trim_dat(data)
%last change: 2008-04-15; line 8: subtract -1
utrim=0.1; % wieviel Prozent sollen unten weggeworfen werden ?
otrim=0.1; % wieviel Prozent sollen oben weggeworfen werden ?

len=length(data);
gu=round(utrim*len);  %Index f�r die untere Grenze des Trimmens
go=round(otrim*len)-1;  %Index f�r die obere Grenze des Trimmens (n-go)

t_sort=sort(data);
if gu>0
    data_trimmed=t_sort(gu:len-go);
else 
    data_trimmed=data;
end
function [trial_info, eye_data] = develop(fname)
%function [trial_info, eye_data] = develop_all(fname)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fix_x, fix_y:     average fixation position
% start fixation:   temporal start of fixation (in sample counts)
% end fixation:     temporal end of fixation (in sample counts)
% fix duration:     fixation duration (end fixation- start fixation) in sample counts
% end_sacc:         raw data case end_sacc
% abs_start_sacc_t: start time of saccade (absolute time)
% abs_end_sacc_t:   end time of saccade (absolute time)
% sacc_dist:        euclidean distance of saccade
% x0, y0:           start position of saccade
% x1, y1:           end position of saccade
% amplitude:        ?? (average position, difference between trial before and after, in visual degree)
% peak_vel:         ??
% last change:      16-05-2006 AL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fname=('PFleft160');
%filename=sprintf('C:\\progs\\adaptive saccades\\matlab progs\\data\\%s.asc', fname);
filename=fname;

file = textread(filename,'%s ','delimiter','\n','whitespace','');
nlines = length(file);
[EYE_USED]=get_eye_used(file);      %which eye was used?

[trial_start]        =string2dat('TRIALSTART', file)/1000; %get absolute time of trial start
%%[trial_end]  =string2dat('END', file)/1000;        %get absolute time of of trial end
[trial_end]          =string2dat('TRIALEND', file)/1000;        %get absolute time of of trial end

%ADD A PROCEDURE TO DEAL WITH THOSE TRIALS WHEN THE STIMULUS BY ACCIDENT
%DID NOT TURN ON; IN THESE CASES, THE TRIAL IS NOT COUNTED AS A TRIAL, BUT
%STILL THERE EXISTS A TRIAL ID; USE TRIAL ERROR AS AN IDENTIFICATION?

%[trial_info.dc]      =string2dat(EYE_USED.dc_name, file);         %get drift correction values for used eye
%[trial_info.trial_id]=string2dat('TRIAL_ID', file);         %get drift correction values for used eye

%avoid multiple events for trial start/ trial end
trial_start = unique(round(trial_start));
trial_end   = unique(round(trial_end));


trial_info.trialduration = trial_end - trial_start;
trial_info.ntrials=length(trial_info.trialduration);

[index.tstart]=find_index('TRIALSTART',file);     %get index of trial start
%[index.tend]  =find_index('END', file);          %get index of trial end (end of recording)
[index.tend]  =find_index('TRIALEND', file);       %get index of trial end (timeout)

%for some reasons the first trial always contains two events "trialstart"
if length(index.tstart) > length(index.tend)
    index.tstart = index.tstart(2:end);
end

%for tcount =1:trial_info.ntrials
%for tcount=7:7
for tcount=1:trial_info.ntrials
    dat =file(index.tstart(tcount):index.tend(tcount));
    %dat =file;
    [nlines, dummy]=size(dat);

    %detect and delete blinks----------------------------------------
    [isblink]=find_index('SBLINK', dat);     %are there any blinks?
        
    if isblink>1 %are there any blinks?
        n_blink=length(isblink);
        for i=1:n_blink
            [index.sblink]=find_index('SBLINK', dat);     %get index of trial start; index has to be computed new every time!
            [index.eblink]=find_index('EBLINK', dat);     %get index of trial start; index has to be computed new every time!
            dat(index.sblink(1):index.eblink(1))=[];
        end
    end
    %--------------------------------
   
%     [index.sacc_s]=find_index('SSACC', dat);     %get index of trial start
%     [index.sacc_e]=find_index('ESACC', dat);     %get index of trial start
%     %what to do if length of indices differs?
% 
%     if abs(length(index.sacc_s)-length(index.sacc_s))>0
%         error('unequal length of start and end of saccade');
%     end
%     %index=delete_unvalid_indices(index); %handle those cases when a saccade started before display onset (remove index for end of that saccade)
%     
%     n_sacc=length(index.sacc_e);
%     for j=1:n_sacc
%     % for j=5:5
%         [eye_data(tcount,j).raw]=get_sacc_pos(dat, index.sacc_s(j),index.sacc_e(j) );
%         %[eye_data.raw(tcount,j)]=get_sacc_pos(dat, index.sacc_s(j),index.sacc_e(j) );
%         
%         %[raw]=get_sacc_pos(dat, index.sacc_s(j),index.sacc_e(j) );
%         %[eye_data(tcount,j).raw]=clean_data(raw.x,raw.y);  %remove offscreen eye positions
%     end
    

    
    [eye_data(tcount).FIX]=string2dat('EFIX', dat);   %get absolute time of fixation start and end, duration, and xy position

    %[eye_data(tcount).SACC]=string2dat('ESACC', dat);   %get absolute time of fixation start and end, duration, and xy position


    %[eye_data.FIX(tcount)]=string2dat('EFIX', dat);   %get absolute time of fixation start and end, duration, and xy position

    %[eye_data.SACC(tcount)]=string2dat('ESACC', dat);   %get absolute time of fixation start and end, duration, and xy position

    
end
t=1;
%----------------------------------------------------


%--------------------------------------------------------------------------

function [index]=find_index(event_type, in)
index=-1;
%GET DISPLAY START
[nlines, dummy]=size(in);
count = 0;
for i = 1:nlines
    if findstr(in{i}, event_type)
        count = count + 1;
        index(count) = i;
    end
end
%--------------------------------------------------------------------------

function[EYE_USED]=get_eye_used(file)
LEFT=0;
RIGHT=0;
for i = 1:length(file)
    if findstr(file{i}, 'EYE_USED 1 LEFT')
        LEFT=1;
    else if findstr(file{i}, 'EYE_USED 1 RIGHT')
            RIGHT=1;
        end
    end
end

EYE_USED.L=LEFT;
EYE_USED.R=RIGHT;

if EYE_USED.L==1
    EYE_USED.dc_name='DRIFTCORRECT L LEFT';
else if EYE_USED.R==1
        EYE_USED.dc_name='DRIFTCORRECT R RIGHT';
    end
end
%--------------------------------------------------------------------------
function [out]=get_sacc_pos(dat, index_s, index_e)

temp_sacc=dat(index_s+1:index_e-1);
[nlines, dummy]=size(temp_sacc);
%CONVERT STRINGS INTO DATA VECTORS
%SAVE IN A TEXT FILE
fid = fopen('temp.txt', 'w');
for i = 1:nlines
    temp = temp_sacc(i,:);
    temp_char = char(temp);
    fprintf(fid, '%s', temp_char);
    fprintf(fid, '\n');
end
fclose(fid);
%'17212838	  402.4	  300.8	 2339.0'
%[sample, out.x, out.y, pupil] = textread('temp.txt', '%d %f %f %f');
[sample, out.x, out.y, pupil, dummy] = textread('temp.txt', '%d %f %f %f %s');
delete('temp.txt'); %DELETE TEXT FILE
%---------------


 function[index]=delete_unvalid_indices(index);
     
 if index.sacc_e(1)<index.sacc_s(1)
     index.sacc_e=index.sacc_e(2:end)
 end

 disp ('saccade started before onset of display; index has been removed from file');
% beep;



function[out]=clean_data(inx,iny)

[out.x,out.y]=find(inx>0 & inx<800 & iny>0 & iny<600);



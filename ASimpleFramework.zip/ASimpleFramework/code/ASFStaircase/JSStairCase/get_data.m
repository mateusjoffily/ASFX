function [pt]=get_data(fname)
%[pt] = get_data('01_06');
fname=sprintf('.\\data\\%s.asc', fname);
data=load(fname);
pt.x=data(:,2);
pt.y=data(:,3);

[pt.x, pt.y]=remove_invalid_pos(pt.x, pt.y);

% if VEL==1
% pt.xvel=data(:,5);
% pt.yvel=data(:,6);
% end
    
    
function [x, y]=remove_invalid_pos(inx, iny)

ind=find(inx>0 & iny>0 & inx<800 & iny<600);
x=inx(ind);
y=iny(ind);
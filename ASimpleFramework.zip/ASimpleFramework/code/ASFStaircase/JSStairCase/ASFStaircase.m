function [TrialInfo] = ASFStaircase(atrial, windowPtr, Stimuli, Cfg)
%function [TrialInfo] = ASFStaircase(atrial, windowPtr, Stimuli, Cfg)
%
%AL wrote it
%20090616   JS redesigned it to have a general form of mUP/nDOWN STAIRCASE
% 
% %----------------------------------------------------
% %DURATION STUFF
% Cfg.StairCase.Stimulation.targetDurationFrames = 30; %at 60 Hz, this corresponds to an exposure duration of 500 ms
% Cfg.StairCase.Stimulation.responseDurationFrames = 120; %at 60 Hz, this corresponds to a response duration (after target) of 2000 ms
% Cfg.StairCase.Stimulation.prePeriodDurationFrames = 12; %at 60 Hz, this corresponds to 200 ms
% Cfg.StairCase.Stimulation.sndTarget1 = MakeBeep(500, 0.1);
% Cfg.StairCase.Stimulation.sndTarget2 = MakeBeep(1000, 0.1);
% 
% 
% %----------------------------------------------------
% %STAIRCASE STUFF
% Cfg.StairCase.nTurnOvers = 20;
% Cfg.StairCase.nSkipTurnOvers = 3;
% Cfg.StairCase.nDown = 2; %choose lower intensity value (more difficult) after two correct trials
% Cfg.StairCase.nUp = 1;% %choose higher intensity value (easier) after one mistake
% Cfg.StairCase.ratioOfCurrentLevelUp = 0.1;  %easier
% Cfg.StairCase.ratioOfCurrentLevelDown = 0.05; %more difficult
% Cfg.StairCase.maxTrials = 100;



%INIT VARIABLES
stimulVec = repmat(NaN, [Cfg.StairCase.maxTrials, 1]); 
responseVec = repmat(NaN, [Cfg.StairCase.maxTrials, 1]);
evalVec = repmat(NaN, [Cfg.StairCase.maxTrials, 1]);
reversalVec = repmat(NaN, [Cfg.StairCase.maxTrials, 1]);
currentLevelVec = repmat(NaN, [Cfg.StairCase.maxTrials, 1]);
changeVec = repmat(NaN, [Cfg.StairCase.maxTrials, 1]);
iTrial = 0;
nReversals = 0;
nextChangeDirection = 0;
previousChangeDirection = 0;

while (iTrial < Cfg.StairCase.maxTrials)&&(nReversals < Cfg.StairCase.nTurnOvers)
    switch atrial.code
        case 99
            %DUMMY TRIAL
            atrial.userDefined(1:6)=0;
            Cfg.StairCase.Stimulation.sndTarget = 0;
            [TrialInfo] = Cfg.StairCase.trialFunction(atrial, windowPtr, Stimuli, Cfg);
            TrialInfo.trial.thresVec = [];
            return
        otherwise
            %STAIRCASE TRIAL
            atrial.userDefined(1) = 0;
            atrial.userDefined(2) = Cfg.StairCase.currentLevel;
            atrial.userDefined(3) = 0;
            atrial.userDefined(4) = 0;

            iTrial = iTrial + 1;
            %THIS VERSION RANDOMIZES WHICH SOUND HIGH OR LOW IS PLAYED AND ASSIGNS CORRESPONDING CORRECT RESPONSE
            temp = rand(1);
            if temp <=0.5
                %sound1
                atrial.correctResponse = 1;
                stimulVec(iTrial) = 1;
                Cfg.StairCase.Stimulation.sndTarget = Cfg.StairCase.Stimulation.sndTarget1;
            else
                %sound2
                atrial.correctResponse = 3;
                stimulVec(iTrial) = 2;
                Cfg.StairCase.Stimulation.sndTarget = Cfg.StairCase.Stimulation.sndTarget2;
            end

            %--------------------------------------------------------------
            %RUN ONE STIMULUS PRESENTATION
            %--------------------------------------------------------------
            fprintf(1, 'Trial: %4d, Current level is %2.2f\n', iTrial, Cfg.StairCase.currentLevel);
            currentLevelVec(iTrial) = Cfg.StairCase.currentLevel;
            [TrialInfo] = Cfg.StairCase.trialFunction(atrial, windowPtr, Stimuli, Cfg);

            
            %--------------------------------------------------------------
            %EVALUATE RESPONSE
            %--------------------------------------------------------------
            fprintf(1, 'REQUIRED: %d, PRESSED %d, ', atrial.correctResponse, TrialInfo.Response.key);
            if isempty(TrialInfo.Response.key)
                responseVec(iTrial) = NaN;
                thisResponseEval = -1; %NO RESPONSE MEANS ERROR
            else
                responseVec(iTrial) = TrialInfo.Response.key;
                if atrial.correctResponse ~= TrialInfo.Response.key
                    %WRONG RESPONSE
                    thisResponseEval = -1;
                    fprintf(1, 'WRONG\n');
                else
                    %CORRECT RESPONSE
                    thisResponseEval = 1;
                    fprintf(1, 'CORRECT\n');
                end
            end
            evalVec(iTrial) = thisResponseEval;
            
            %--------------------------------------------------------------
            %DO WE HAVE TO CHANGE THE CURRENT INTENSITY LEVEL?
            %--------------------------------------------------------------
            if thisResponseEval == 1
                if iTrial >= Cfg.StairCase.nDown
                    %THIS ONE IS CORRECT
                    tmp = evalVec((iTrial - Cfg.StairCase.nDown + 1):iTrial);
                    %CHECK WHETHER A CHANGE IS ALREADY ALLOWED
                    lastChange = max(find((changeVec == -1)|(changeVec == 1)));
                    if isempty(lastChange)
                        lastChange = 0;
                    end
                    if (lastChange <= iTrial - Cfg.StairCase.nDown) && (sum(tmp) >= Cfg.StairCase.nDown)
                        %WE HAD ENOUGH CORRECT RESPONSES IN A ROW THAT WE CAN
                        %DECREASE STIMULUS INTENSITY
                        nextChangeDirection = -1; %INTENSITY GOING DOWN
                        Cfg.StairCase.currentLevel = Cfg.StairCase.currentLevel - Cfg.StairCase.currentLevel * Cfg.StairCase.ratioOfCurrentLevelDown;
                        fprintf(1, 'CHANGE INTENSITY LEVEL TO %5.3f\n', Cfg.StairCase.currentLevel);
                        changeVec(iTrial) = -1; %DECREASE
                        
                    end
                end
            else
                %THIS ONE IS WRONG
                if iTrial >= Cfg.StairCase.nUp
                    tmp = evalVec((iTrial - Cfg.StairCase.nUp + 1):iTrial);
                    %CHECK WHETHER A CHANGE IS ALREADY ALLOWED
                    lastChange = max(find((changeVec == -1)|(changeVec == 1)));
                    if isempty(lastChange)
                        lastChange = 0;
                    end
                    if (lastChange <= iTrial - Cfg.StairCase.nUp) && (sum(tmp) <= Cfg.StairCase.nUp)
                        %WE HAD WRONG RESPONSES IN A ROW THAT WE CAN INCREASE
                        %STIMULIS INTENSITY
                        nextChangeDirection = 1; %INTENSITY GOING UP
                        Cfg.StairCase.currentLevel = Cfg.StairCase.currentLevel + Cfg.StairCase.currentLevel * Cfg.StairCase.ratioOfCurrentLevelUp;
                        fprintf(1, 'CHANGE INTENSITY LEVEL TO %5.3f\n', Cfg.StairCase.currentLevel);
                        changeVec(iTrial) = 1; %INCREASE
                    end
                end
            end

            %--------------------------------------------------------------
            %WAS THIS A REVERSAL?
            %--------------------------------------------------------------
            if (previousChangeDirection ~=0)
                if(previousChangeDirection == nextChangeDirection)
                    %NO REVERSAL
                    reversalVec(iTrial) = 0;
                else
                    %REVERSAL
                    reversalVec(iTrial) = 1;
                    nReversals = nReversals + 1;
                    fprintf(1, 'Reversal %3d\n', nReversals);
                end
            end

            %ALREADY PREPARING NEXT TRIAL
            previousChangeDirection = nextChangeDirection; %KEEP TRACK OF WHAT HAPPENED BEFORE

    end

    %----------------------------------------------------------------------
    % VISUAL FEEDBACK
    %----------------------------------------------------------------------
    subplot(1, 2, 1)
    plot(1:Cfg.StairCase.maxTrials, currentLevelVec, 'o-')
    title(sprintf('Trial %d', iTrial));
    hold on
    casesCorrect = find(evalVec == 1);
    ph_c = plot(casesCorrect, currentLevelVec(casesCorrect), 'o');
    set(ph_c, 'MarkerEdgeColor', 'g', 'MarkerFaceColor', 'g')
    casesErr = find(evalVec == -1);
    ph_e = plot(casesErr, currentLevelVec(casesErr), 'o');
    set(ph_e, 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r')
    hold on
    cases = find(~isnan(reversalVec) & (reversalVec ~=0));
    ph_r = plot(cases, currentLevelVec(cases), 'ok', 'LineWidth', 2);
    
    %text(cases, currentLevelVec(cases), 'REV')
    hold off
    drawnow

    subplot(1, 2, 2)
    bar(changeVec)
    drawnow

end

%--------------------------------------------------------------------------
%THRESHOLD IS THE AVERAGE OF THE STIMULUS INTENSITY AT REVERSALS (FIRST
%Cfg.StairCase.nSkipTurnOvers ARE SKIPPED)
%--------------------------------------------------------------------------
casesReversals = find(reversalVec == 1);
if length(casesReversals) > Cfg.StairCase.nSkipTurnOvers
    thresh = mean(currentLevelVec(casesReversals(Cfg.StairCase.nSkipTurnOvers+1 : end)));
    fprintf(1, 'CALCULATING THRESHOLD BASED ON %d REVERSALS: %7.4f\n', thresh);
else
    thresh = [];
end

%--------------------------------------------------------------------------
%COLLECT RELEVANT INFORMATION AND STORE IT IN STRUCTURE
%--------------------------------------------------------------------------
TrialInfo.trial.currentLevelVec = currentLevelVec;
TrialInfo.trial.responseVec = responseVec;
TrialInfo.trial.evalVec = evalVec;
TrialInfo.trial.changeVec = changeVec;
TrialInfo.trial.reversalVec = reversalVec;
TrialInfo.trial.reversals = casesReversals;
TrialInfo.trial.thresh = thresh;


function [xEst] = estimateThreshold(X, y1, thres)
%example call:
%x = [0.04 0.08 0.16 0.32 0.64];
%y1 = [0.5 0.6 0.7 0.8 0.9];
%thres = 0.75
%[xEst] = estimateThreshold(x, y1, thres)

Cfg.doPlot = 1;

%thresh = 0.75; %get me the print size that leads to 0.75% performance

N = 1;

%delete NaNs
ind = isnan(y1);
ind = find(ind==1);
XNoNans = X;
y1NoNans = y1;
XNoNans(ind)=[];
y1NoNans(ind)=[];

if length(XNoNans) < 3
    warning('too few data points for estimation');
    waitforbuttonpress;
end

xLog2 = log2(XNoNans);
y1Log2 = log2(y1NoNans);
xLog = log(XNoNans);
%y1Log = ln(y1NoNans);
figure;
plot(xLog, y1NoNans, 'ko-');
waitforbuttonpress;
[p, s]=polyfit(xLog2, y1Log2, N);
y1Est=polyval(p, xLog2);

%[p, s]=polyfit(xLog2, y1NoNans, N);
%y1Est=polyval(p, xLog2);

% 
% if Cfg.doPlot == 1
%     figure;
%     subplot(2,2,1);
%     h1=plot(xLog2, y1Est, 'k--');
%     set(h1, 'linewidth', 2);
%     hold on;
%     h2=plot(xLog2, y1Log2, 'ro');
%     set(h2, 'linewidth', 2, 'markersize', 16, 'markerfacecolor', 'w', 'markeredgecolor', 'w');
%     hold on;
%     h3=plot(xLog2, y1Log2, 'ro');
%     set(h3, 'linewidth', 2, 'markersize', 14, 'markerfacecolor', 'w', 'markeredgecolor', 'r');
% 
%     axis([-4 0 -4 0]);
%     set(gca, 'linewidth', 2, 'fontsize', 20);
% end

x = [];
y = log2(thres);
m = p(1);
c = p(2);
%y = m*x + c;


x = 2^((y - c)/m);
xEst = x;
figure
if Cfg.doPlot == 1;
    %subplot(2,2,2);
    h1=plot(X, y1, 'k--');
    set(h1, 'linewidth', 2);
    hold on;
    h2=plot(X, y1, 'ro');
    set(h2, 'linewidth', 2, 'markersize', 16, 'markerfacecolor', 'w', 'markeredgecolor', 'w');
    hold on;
    h3=plot(X, y1, 'ro');
    set(h3, 'linewidth', 2, 'markersize', 14, 'markerfacecolor', 'w', 'markeredgecolor', 'r');
    hline = line([xEst xEst], [0 thres]);
    set(hline, 'color', 'k');
    hline = line([min(X) xEst], [thres thres]);
    set(hline, 'color', 'k');
    
    axis([min(XNoNans) max(XNoNans) 0 1]);
    set(gca, 'linewidth', 2, 'fontsize', 20);
end

t =1;
function runCrowdingStaircase(subject, session, trialType, ecc, Cfg)
%function runCrowdingStaircase(subject, session, trialType, ecc)
%----------------------------------------------------
%created 03/2009 angelika.lingnau@unitn.it
%last change: 2009-03-13 AL
%----------------------------------------------------
%example call (exptype 'single'): 
% Cfg = [];
%runCrowdingStaircase(4, 1, 'single',   12, Cfg) 
% Cfg = [];
%runCrowdingStaircase(4, 2, 'single',  -12, Cfg)  
% Cfg = [];
%runCrowdingStaircase(4, 3, 'single',  -12, Cfg) 
% Cfg = [];
%runCrowdingStaircase(4, 4, 'single',   12, Cfg)  
% Cfg = [];
%runCrowdingStaircase(4, 5, 'single',   12, Cfg) 
% Cfg = [];
%runCrowdingStaircase(4, 6, 'single',  -12, Cfg) 

%-------------------------------------------------------------------------
%example call (exptype 'flanker'): 
%Cfg.grating.cpd = 3.2041; %FP, upper visual field
%runCrowdingStaircase(7, 1, 'flanker',  -12)  
%
%Cfg.grating.cpd = 3.6731; %FP, lower visual field
%runCrowdingStaircase(7, 2, 'flanker',  12)  
%
%Cfg.grating.cpd = 3.6731; %FP, lower visual field
%runCrowdingStaircase(7, 3, 'flanker',  12)  
%
%Cfg.grating.cpd = 3.2041; %FP, upper visual field
%runCrowdingStaircase(7, 4, 'flanker',  -12)  
%
%Cfg.grating.cpd = 3.6731; %FP, lower visual field
%runCrowdingStaircase(7, 5, 'flanker',  12)  
%
%Cfg.grating.cpd = 3.2041; %FP, upper visual field
%runCrowdingStaircase(7, 6, 'flanker',  -12)  

%----------------------------------------------------
%EYETRACKING STUFF
Cfg.Eyetracking.useEyelink = 0;                  
Cfg.Eyetracking.useEyelinkMouseMode = 0;
Cfg.Eyetracking.doCalibration = 0;               
Cfg.Eyetracking.doDriftCorr=0;
Cfg.Eyetracking.largeCalibTargets = 0;

%----------------------------------------------------
%SCREEN STUFF
%SCREEN EYE TRACKING LAB
% Cfg.Screen.Resolution.width = 1280;
% Cfg.Screen.Resolution.height = 1024;
% Cfg.Screen.distanceCm = 80;
% Cfg.Screen.xDimCm = 39.5; 
% Cfg.Screen.yDimCm = 29;

%LARGE SCREEN JS
Cfg.Screen.Resolution.width = 1920;%1280;%1650; %% %FRANCESCA, please check if this is the resolution we are currently using (I'm pretty sure)
Cfg.Screen.Resolution.height = 1200;%1024;%1050; ;%%FRANCESCA, please check if this is the resolution we are currently using (I'm pretty sure)
Cfg.Screen.distanceCm = 80;%was 80% 135
Cfg.Screen.xDimCm = 51.5;
Cfg.Screen.yDimCm = 32.5;

%LARGE SCREEN ANGELIKA
% Cfg.Screen.Resolution.width = 1680;%1280;%1650; %% %FRANCESCA, please check if this is the resolution we are currently using (I'm pretty sure)
% Cfg.Screen.Resolution.height = 1050;%1024;%1050; ;%%FRANCESCA, please check if this is the resolution we are currently using (I'm pretty sure)
% Cfg.Screen.distanceCm = 80;%was 80% 135
% Cfg.Screen.xDimCm = 51.5;
% Cfg.Screen.yDimCm = 32.5;

%LAPTOP SCREEN ANGELIKA
% Cfg.Screen.Resolution.width = 1680;%1280;%1650; %% %FRANCESCA, please check if this is the resolution we are currently using (I'm pretty sure)
% Cfg.Screen.Resolution.height = 1050;%1024;%1050; ;%%FRANCESCA, please check if this is the resolution we are currently using (I'm pretty sure)
% Cfg.Screen.distanceCm = 80;%was 80% 135
% Cfg.Screen.xDimCm = 32.0;%37.5;%60;%39;%24              %physical width (cm) of the screen; FRANCESCA, please check 
% Cfg.Screen.yDimCm = 20.5;


Cfg.Screen.color = [255/2, 255/2, 255/2];
%Cfg.Screen.rect = [0 0 1280*0.5 1024*0.5];
%Cfg.Screen.rect = [1 1 Cfg.Screen.Resolution.width*0.75 Cfg.Screen.Resolution.height*0.75];
Cfg.Screen.rect = [];
%[angle] = calc_angle_from_size(20, Cfg.Screen.distanceCm, 1, Cfg.Screen.Resolution.width/Cfg.Screen.xDimCm);

Cfg.pos.targetEccXDeg = 0;
Cfg.pos.targetEccYDeg = ecc;
Cfg.pos.targetEccXPix = 0;
[dummy, Cfg.pos.targetEccYPix] = calc_size_from_angle(ecc, Cfg.Screen.distanceCm, Cfg.Screen.Resolution.height/Cfg.Screen.yDimCm); %this is the size of the target (in pixel) to reach 1.6�; see Masuda et al., 2008
%[dummy, Cfg.pos.targetEccYPix] = calc_size_from_angle(ecc, Cfg.Screen.distanceCm, Cfg.Screen.Resolution.width/Cfg.Screen.xDimCm); %this is the size of the target (in pixel) to reach 1.6�; see Masuda et al., 2008
%Cfg.pos.distanceBetweenGratingCentresDeg = 1.5;
%[dummy, Cfg.pos.distanceBetweenGratingCentresPix] = calc_size_from_angle(Cfg.pos.distanceBetweenGratingCentresDeg, Cfg.Screen.distanceCm, Cfg.Screen.Resolution.width/Cfg.Screen.xDimCm); %this is the size of the target (in pixel) to reach 1.6�; see Masuda et al., 2008


Cfg.pos.x0 = Cfg.Screen.Resolution.width/2;

if ecc >0 %target in the lower visual field
    Cfg.pos.y0 = Cfg.Screen.Resolution.height/10; %present fixation cross at the upper boarder of the screen
else if ecc <0 %target in the upper visual field
    Cfg.pos.y0 = Cfg.Screen.Resolution.height - Cfg.Screen.Resolution.height/10; %present fixation cross at the lower boarder of the screen
    else
        if ecc == 0
            Cfg.pos.y0 = Cfg.Screen.Resolution.height/2; %present fixation cross at the centre of the screen
        end
    end
end



%Cfg.timeout = 1;                     %How many seconds are available for responding at the end of a mini block? FRANCESCA, please try out if this is long enough. Feel free to adjust.
%----------------------------------------------------
%DURATION STUFF
Cfg.dur.targetDurationFrames = 5; %[9]; %with 75 Hz, this corresponds to an exposure duration of 120 ms
Cfg.dur.responseDurationFrames = 120; %with 75 Hz, this corresponds to a response duration (after each triplet) of 1600 ms
Cfg.dur.prePeriodDurationFrames = 12; %200 ms
Cfg.sndStart = MakeBeep(500, 0.1);
%----------------------
%GRATING STUFF
%Cfg.grating.sizeGratingDegree = 1;%
%Cfg.grating.applyGaussian = 1;
Cfg.grating.sizeGratingDegree = 1;%
Cfg.grating.applyGaussian = 1;
%[cm, Cfg.grating.ppd] = calc_size_from_angle(1, Cfg.Screen.distanceCm, Cfg.Screen.Resolution.width/Cfg.Screen.xDimCm); %how many pixel are covered by one degree?
[cm, Cfg.grating.ppd] = calc_size_from_angle(1, Cfg.Screen.distanceCm, Cfg.Screen.Resolution.height/Cfg.Screen.yDimCm); %how many pixel are covered by one degree?


widthOfGrid = Cfg.grating.ppd * Cfg.grating.sizeGratingDegree; %grating covers 2 degree of visual angle
halfWidthOfGrid = widthOfGrid / 2;

Cfg.grating.widthArray = (-halfWidthOfGrid) : halfWidthOfGrid;  % widthArray is used in creating the meshgrid.
Cfg.grating.thisGray = 128;  % Computes the CLUT color code for gray.
Cfg.grating.black = Cfg.grating.thisGray - 58;%this roughly corresponds to 50% michelson contrast;
Cfg.grating.white = Cfg.grating.thisGray + 58;%this roughly corresponds to 50% michelson contrast;       
Cfg.grating.michelContrast = 0.50; %this is just for documentation, it does not change the actual value
Cfg.grating.absoluteDifferenceBetweenWhiteAndGray = abs(Cfg.grating.white - Cfg.grating.thisGray);
Cfg.grating.tiltInDeg = 45; %either 45 to the left or right with respect to upright (0�)

%----------------------------------------------------
%STAIRCASE STUFF
Cfg.staircase.nTurnOvers = 20;
Cfg.staircase.nSkipTurnOvers = 3;
Cfg.staircase.nDown = 1; %choose easier value after one mistake
Cfg.staircase.nUp = 2;%2; %choose more difficult value after two correct answers in a row
Cfg.staircase.ratioOfCurrentLevelUp = 0.1;  %easier
Cfg.staircase.ratioOfCurrentLevelDown = 0.05; %more difficult
Cfg.staircase.maxTrials =100;
Cfg.staircase.trialType = trialType;
Cfg.staircase.currentLevelDeg = 2; %start value for flanker task
                                         
%----------------------------------------------------
%MIXED
Cfg.responseTerminatesTrial = 0;
%Cfg.fixCentre = [Cfg.Screen.Resolution.width/2 Cfg.Screen.Resolution.height/2];
%Cfg.nRep = 1;        
Cfg.feedbackTrialCorrect = 0;
Cfg.feedbackTrialError = 0;
%Cfg.maxLength = 3; %5; maximum number of letters

Cfg.size.Fix = 40;
Cfg.TargetOnPage = 2;%1
%function getIntensityFromContrast.m

drawToScreen(subject, Cfg); %FRANCESCA, this program only has to be started once on the eye tracker PC to draw the correct bitmaps; afterwards, you can comment this
%expression; next time you start the program, the saved bitmaps will automatically be used

switch trialType
    case 'single' %[-6 -4 -2 0, 2, 4, 6]; a, B
        
        Cfg.grating.showFlankers = 0;
        Cfg.grating.cpd = -1;
        Cfg.userSuppliedTrialFunction = @ASFStaircase;
        Cfg.userDefinedSTMcolumns = 1;%9;%was 5
        Cfg.staircase.currentLevel = 2; %this is the start level (cpd); choose 4 for eccentricity 10; choose 2 for eccentricity 20

        create_trialdef_CrowdingStaircase(subject, session, Cfg);
    case 'flanker' %[-6 -4 -2 0, 2, 4, 6]; a, B
        
        Cfg.grating.showFlankers = 1;
        %Cfg.grating.cpd = 2.5; %AL, lower visual field
        %Cfg.grating.cpd = 2; %AL, upper visual field
        Cfg.userSuppliedTrialFunction = @ASFStaircase;
        Cfg.userDefinedSTMcolumns = 1;%9;%was 5
        
        %this is the start level (distPix between target and flankers);
        %distDeg = 3;
        [cm, Cfg.staircase.currentLevel] = calc_size_from_angle(Cfg.staircase.currentLevelDeg, Cfg.Screen.distanceCm, Cfg.Screen.Resolution.width/Cfg.Screen.xDimCm);
        %[cm, Cfg.staircase.currentLevel] = calc_size_from_angle(2, Cfg.Screen.distanceCm, Cfg.Screen.Resolution.height/Cfg.Screen.yDimCm);
        
        create_trialdef_CrowdingStaircase(subject, session, Cfg);
end


stdName = 'stimdef.std';
trdName = sprintf('%02d_%02d.trd', subject, session);
sName = sprintf('%02d_%02d', subject, session);
[ExpInfo] = ASF(stdName, trdName, sName, Cfg);

figure
plot(ExpInfo.TrialInfo(2).trial.thresVecCPD, '-o')
close all;
clear all;
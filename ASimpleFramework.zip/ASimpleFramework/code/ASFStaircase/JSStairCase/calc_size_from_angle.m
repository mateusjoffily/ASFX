function [cm, pixel] = calc_size_from_angle(angle, dist, pixel_per_cm)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculates the size of a stimulus (in cm/ pixel) from a given angle 
% (in degree) and a specified distance to the screen
% example:
% [cm, pixel] = calc_size_from_angle(7.93, 85, 50.9)
% 
% in addition, the size is calculated in pixel;
% therefore, the correct size and resolution of the screen 
% has to be specified; these values can be extracted via 
% the program devcaps1.c
% LAPTOP
% size screen      :   33 *   20.6 cm
% resolution screen: 1680 * 1050 pixel
% resolution screen: 1280 * 1024 pixel
%
% desktop PC
% size screen      : 37.5 *   30 cm
% resolution screen: 1680 * 1050 pixel
% resolution screen: 1280 * 1024 pixel


cm=tan(degree_to_radian(angle/2))*dist*2;

pixel=cm*pixel_per_cm;

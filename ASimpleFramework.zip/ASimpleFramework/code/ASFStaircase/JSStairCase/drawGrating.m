function drawGrating(windowPtr, tiltInDegrees, cpd, distPix, Cfg)
%draws grating with specified angle and cpd to backbuffer
%last change: 2009-03-13 AL
% ---------- Parameter Setup ----------
%Cfg.grating.x0 = x0;
%Cfg.pos.y0 = y0;
%Cfg.grating.shiftX = shiftX; %shift with respect to fixation
%Cfg.grating.shiftY = shiftY; %shift with respect to fixation
expName = 'test';

% Prevents MATLAB from reprinting the source code when the program runs.
%echo off

% *** To rotate the grating, set tiltInDegrees to a new value.
tiltInDegreesStandard = 0;
tiltInRadians = tiltInDegreesStandard * pi / 180; % The tilt of the grating in radians.

% *** To lengthen the period of the grating, increase pixelsPerPeriod.
pixelsPerPeriod = Cfg.grating.ppd / cpd; % 50 How many pixels will each period/cycle occupy?
spatialFrequency = 1 / pixelsPerPeriod; % How many periods/cycles are there in a pixel?
radiansPerPixel = spatialFrequency * (2 * pi); % = (periods per pixel) * (2 pi radians per period)

% *** To enlarge the gaussian mask, increase periodsCoveredByOneStandardDeviation.
% The parameter "periodsCoveredByOneStandardDeviation" is approximately
% equal to
% the number of periods/cycles covered by one standard deviation of the radius of
% the gaussian mask.
%periodsCoveredByOneStandardDeviation = 1.5;
periodsCoveredByOneStandardDeviation = cpd * Cfg.grating.sizeGratingDegree * 0.2;
% The parameter "gaussianSpaceConstant" is approximately equal to the
% number of pixels covered by one standard deviation of the radius of
% the gaussian mask.
gaussianSpaceConstant = periodsCoveredByOneStandardDeviation  * pixelsPerPeriod;
%gaussianSpaceConstant = periodsCoveredByOneStandardDeviation  * cpd;

% *** If the grating is clipped on the sides, increase widthOfGrid.
%widthOfGrid = 400;
% widthOfGrid = Cfg.ppd * Cfg.sizeGratingDegree; %grating covers 2 degree of visual angle
% halfWidthOfGrid = widthOfGrid / 2;
% widthArray = (-halfWidthOfGrid) : halfWidthOfGrid;  % widthArray is used in creating the meshgrid.


% For an explanation of the try-catch block, see the section "Error Handling"
% at the end of this document.
%try

% ---------- Window Setup ----------
% Opens a window.

% Screen is able to do a lot of configuration and performance checks on
% open, and will print out a fair amount of detailed information when
% it does.  These commands supress that checking behavior and just let
% the demo go straight into action.  See ScreenTest for an example of
% how to do detailed checking.
%oldVisualDebugLevel = Screen('Preference', 'VisualDebugLevel', 3);
%oldSupressAllWarnings = Screen('Preference', 'SuppressAllWarnings', 1);

% Find out how many screens and use largest screen number.
%whichScreen = max(Screen('Screens'));
%[windowPtr, Cfg] = InitScreen(Cfg, expName);

% Hides the mouse cursor
HideCursor;

% Taking the absolute value of the difference between white and gray will
% help keep the grating consistent regardless of whether the CLUT color
% code for white is less or greater than the CLUT color code for black.
%absoluteDifferenceBetweenWhiteAndGray = abs(white - thisGray);

% ---------- Image Setup ----------
% Stores the image in a two dimensional matrix.

% Creates a two-dimensional square grid.  For each element i = i(x0, y0) of
% the grid, x = x(x0, y0) corresponds to the x-coordinate of element "i"
% and y = y(x0, y0) corresponds to the y-coordinate of element "i"
[x y] = meshgrid(Cfg.grating.widthArray, Cfg.grating.widthArray);

% The equation of a line passing through the origin with angle theta
% from the horizontal is "y = tan(theta) * x"
% The equation of a line passing through the y-intercept "b" with angle
% theta from the horizontal is "y = tan(theta) * x + b" which can be
% rewritten "y - tan(theta) * x = b," where different values of "b" correspond to
% different lines.
% Imposing the relationship "y - tan(theta) .* x = gradientMeshGrid"
% will create a mesh such that elements along a line with angle theta have
% the same value.
gradientMeshGrid = y - tan(tiltInRadians) .* x;

% Converts gradientMeshGrid into a sinusoidal grating, where elements
% along a line with angle theta have the same value and where the
% period of the sinusoid is approximately equal to "pixelsPerPeriod" pixels.
% Note that each entry of gratingMatrix varies between minus one and
% one; -1 <= gratingMatrix(x0, y0)  <= 1
gratingMatrix = sin(radiansPerPixel .* gradientMeshGrid);

% Creates a circular Gaussian mask centered at the origin, where the number
% of pixels covered by one standard deviation of the radius is
% approximately equal to "gaussianSpaceConstant."
% For more information on circular and elliptical Gaussian distributions, please see
% http://mathworld.wolfram.com/GaussianFunction.html
% Note that since each entry of circularGaussianMaskMatrix is "e"
% raised to a negative exponent, each entry of
% circularGaussianMaskMatrix is one over "e" raised to a positive
% exponent, which is always between zero and one;
% 0 < circularGaussianMaskMatrix(x0, y0) <= 1
circularGaussianMaskMatrix = exp(-((x .^ 2) + (y .^ 2)) / (gaussianSpaceConstant ^ 2));

%maskThresh=0.001;
%circularGaussianMaskMatrix(find(circularGaussianMaskMatrix<maskThresh))=128;


% Since each entry of gratingMatrix varies between minus one and one and each entry of
% circularGaussianMaskMatrix vary between zero and one, each entry of
% imageMatrix varies between minus one and one.
% -1 <= imageMatrix(x0, y0) <= 1

switch Cfg.grating.applyGaussian
    case 0
        imageMatrix = gratingMatrix;
    case 1
        imageMatrix = gratingMatrix .* circularGaussianMaskMatrix;
end
        
% Since each entry of imageMatrix is a fraction between minus one and
% one, multiplying imageMatrix by absoluteDifferenceBetweenWhiteAndGray
% and adding the gray CLUT color code baseline
% converts each entry of imageMatrix into a shade of gray:
% if an entry of "m" is minus one, then the corresponding pixel is black;
% if an entry of "m" is zero, then the corresponding pixel is gray;
% if an entry of "m" is one, then the corresponding pixel is white.
grayscaleImageMatrix = Cfg.grating.thisGray + Cfg.grating.absoluteDifferenceBetweenWhiteAndGray * imageMatrix;

[nrows, ncols] = size(grayscaleImageMatrix);

% ---------- Image Display ----------
% Displays the image in the window.

% Colors the entire window gray.
Screen('FillRect', windowPtr, Cfg.Screen.color);
textureIndex=Screen('MakeTexture', windowPtr, grayscaleImageMatrix);



Screen('DrawTexture', windowPtr, textureIndex, [1 1 ncols nrows], [Cfg.pos.x0 + Cfg.pos.targetEccXPix - ncols/2 Cfg.pos.y0 + Cfg.pos.targetEccYPix - nrows/2 Cfg.pos.x0 + Cfg.pos.targetEccXPix + ncols/2 Cfg.pos.y0 + Cfg.pos.targetEccYPix + nrows/2], tiltInDegrees,  1, 1);

if Cfg.grating.showFlankers == 1
    %distPix
    %Cfg.pos.flankL.x0 = Cfg.pos.x0 + Cfg.pos.targetEccXPix - Cfg.pos.distanceBetweenGratingCentresPix;
    Cfg.pos.flankL.x0 = Cfg.pos.x0 + Cfg.pos.targetEccXPix - distPix;
    Cfg.pos.flankL.y0 = Cfg.pos.y0 + Cfg.pos.targetEccYPix;

    %Cfg.pos.flank2L.x0 = Cfg.pos.x0 + Cfg.pos.targetEccXPix - 2*Cfg.pos.distanceBetweenGratingCentresPix;
    Cfg.pos.flank2L.x0 = Cfg.pos.x0 + Cfg.pos.targetEccXPix - 2*distPix;
    Cfg.pos.flank2L.y0 = Cfg.pos.y0 + Cfg.pos.targetEccYPix;
    
    %Cfg.pos.flankR.x0 = Cfg.pos.x0 + Cfg.pos.targetEccXPix + Cfg.pos.distanceBetweenGratingCentresPix;
    Cfg.pos.flankR.x0 = Cfg.pos.x0 + Cfg.pos.targetEccXPix + distPix;
    Cfg.pos.flankR.y0 = Cfg.pos.y0 + Cfg.pos.targetEccYPix;

    %Cfg.pos.flank2R.x0 = Cfg.pos.x0 + Cfg.pos.targetEccXPix + 2*Cfg.pos.distanceBetweenGratingCentresPix;
    Cfg.pos.flank2R.x0 = Cfg.pos.x0 + Cfg.pos.targetEccXPix + 2*distPix;
    Cfg.pos.flank2R.y0 = Cfg.pos.y0 + Cfg.pos.targetEccYPix;

    
    temp = randperm(2)-1;
    thisTiltInDegrees = temp(1)*90+Cfg.grating.tiltInDeg; 
    Screen('DrawTexture', windowPtr, textureIndex, [1 1 ncols nrows], [Cfg.pos.flankL.x0 - ncols/2 Cfg.pos.flankL.y0 - nrows/2 Cfg.pos.flankL.x0 + ncols/2 Cfg.pos.flankL.y0 + nrows/2], thisTiltInDegrees,  1, 1);
    temp = randperm(2)-1;
    thisTiltInDegrees = temp(1)*90+Cfg.grating.tiltInDeg; 
    Screen('DrawTexture', windowPtr, textureIndex, [1 1 ncols nrows], [Cfg.pos.flankR.x0 - ncols/2 Cfg.pos.flankR.y0 - nrows/2 Cfg.pos.flankR.x0 + ncols/2 Cfg.pos.flankR.y0 + nrows/2], thisTiltInDegrees,  1, 1);

    temp = randperm(2)-1;
    thisTiltInDegrees = temp(1)*90+Cfg.grating.tiltInDeg; 
    Screen('DrawTexture', windowPtr, textureIndex, [1 1 ncols nrows], [Cfg.pos.flank2L.x0 - ncols/2 Cfg.pos.flank2L.y0 - nrows/2 Cfg.pos.flank2L.x0 + ncols/2 Cfg.pos.flank2L.y0 + nrows/2], thisTiltInDegrees,  1, 1);
    temp = randperm(2)-1;
    thisTiltInDegrees = temp(1)*90+Cfg.grating.tiltInDeg; 
    Screen('DrawTexture', windowPtr, textureIndex, [1 1 ncols nrows], [Cfg.pos.flank2R.x0 - ncols/2 Cfg.pos.flank2R.y0 - nrows/2 Cfg.pos.flank2R.x0 + ncols/2 Cfg.pos.flank2R.y0 + nrows/2], thisTiltInDegrees,  1, 1);

    
    %Screen('DrawTexture', windowPtr, textureIndex, [1 1 ncols nrows], [Cfg.pos.x0 + Cfg.grating.flankPosL(1) - ncols/2 Cfg.pos.y0 + Cfg.grating.flankPosL(2) - nrows/2 Cfg.pos.x0 + Cfg.grating.flankPosL(1) + ncols/2 Cfg.pos.y0 + Cfg.grating.tpos(2) + nrows/2], tiltInDegrees,  1, 1);
    %Screen('DrawTexture', windowPtr, textureIndex, [1 1 ncols nrows], [Cfg.pos.x0 + Cfg.grating.flankPosR(1) - ncols/2 Cfg.pos.y0 + Cfg.grating.flankPosR(2) - nrows/2 Cfg.pos.x0 + Cfg.grating.flankPosR(1) + ncols/2 Cfg.pos.y0 + Cfg.grating.tpos(2) + nrows/2], tiltInDegrees,  1, 1);
end


%draw fixation cross
Screen('DrawLine', windowPtr, [0 0 0], Cfg.pos.x0 - Cfg.size.Fix/2, Cfg.pos.y0,  Cfg.pos.x0 + Cfg.size.Fix/2, Cfg.pos.y0, 4);
Screen('DrawLine', windowPtr, [0 0 0], Cfg.pos.x0, Cfg.pos.y0  - Cfg.size.Fix/2,  Cfg.pos.x0, Cfg.pos.y0 +  Cfg.size.Fix/2, 4);





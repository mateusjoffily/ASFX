%function [returnError] = initStim(bufferSize, trOut, p1, p2)
%function [returnError] = initStim(p1, p2)
function [returnError] = initPiezo()
% minimum program for QUAEROSYS tactile stimulator
% commented with the description of all the needed parts
%GPDM wrote it

% bufferSize = 150000; %JS WHAT KIND OF BUFFER IS THIS?
% trOut = 0;  %JS WHAT IS THIS?

%if isempty(bufferSize), bufferSize=150000; else end; % default buffer
%if isempty(trOut), trOut=0; else end; % default trigger out = "No"
%if isempty(p1), p1=4095; else end; % default trigger out = "No"
%if isempty(p2), p2=4095; else end; % default trigger out = "No"

%loadlibrary stimlib0.dll stimlibrel.h alias stimlib ;
% The next callib has to be done every time !!!! 
%JS EVERYTIME WHAT? EVERYTIME THE DLL IS CALLED?
calllib('stimlib', 'initStimulator', '68105517796932851779Y5KB0A3AAG');

% setting the first DAC to 0, 2nd and 3rd to full scale
% and those are to be done every time after an init !!!
% otherwise, are set to zero, i.e. no pin coming up ...

calllib('stimlib', 'setDAC', 0, 0);
calllib('stimlib', 'setDAC', 1, 1024);
calllib('stimlib', 'setDAC', 2, 2047);
calllib('stimlib', 'setDAC', 3, 4095);

% Note, we can think of using DAC 1 for full height and 2 for half height,
% other wise

% increase the size of the local buffer, for longer sequences

%gp calllib('stimlib', 'setProperty','local_buffer_size',bufferSize);

% uncomment if using an external trigger
% calllib('stimlib', 'waitForTrigger',16,0)

% trigger on the rising edge, 
% the sequence is sent out 25-250 us after the trigger comes


% sending out a trigger on the trigger out port
% 
% comment if not needed

% calllib('stimlib', 'triggerOut',16,trOut);

returnError = 0; %JS UNDER WHICH CIRCUMSTANCE CAN WE GET AN ERROR?



function Cfg = junk(Cfg)
Cfg.ASFVersion = 0.34;
%SCREEN SETTINGS
if ~isfield(Cfg, 'Screen'), Cfg.Screen = []; else end;
%if ~isfield(Cfg.Screen, 'rect'), Cfg.Screen.rect = [1, 1, 320, 240];, else, end;
if ~isfield(Cfg.Screen, 'rect'), Cfg.Screen.rect = []; else end;
if ~isfield(Cfg.Screen, 'color'), Cfg.Screen.color = [255, 255, 255]; else end;% [{[255, 255, 255]}|[R, G, B]]
if ~isfield(Cfg.Screen, 'Resolution'), Cfg.Screen.Resolution = []; else end;
if ~isfield(Cfg.Screen.Resolution, 'width'), Cfg.Screen.Resolution.width = 1280; else end;
if ~isfield(Cfg.Screen.Resolution, 'height'), Cfg.Screen.Resolution.height = 800; else end;
if ~isfield(Cfg.Screen.Resolution, 'pixelSize'), Cfg.Screen.Resolution.pixelSize = 32; else end;
if ~isfield(Cfg.Screen, 'refreshRateHz'), Cfg.Screen.refreshRateHz = 60; else end;
if ~isfield(Cfg.Screen, 'fontSize'), Cfg.Screen.fontSize = 24; end;
if ~isfield(Cfg.Screen, 'fontName'), Cfg.Screen.fontName = 'Courier New'; end;
%SHOULD BE CALLED Cfg.Screen.useBackBuffer
if ~isfield(Cfg, 'useBackBuffer')
    Cfg.Screen.useBackBuffer = 1;
else
    fprintf(1, 'WARNING Cfg.useBackBuffer should be called Cfg.Screen.useBackBuffer\n');
    rmfield(Cfg, 'useBackBuffer'); 
end
if ~isfield(Cfg.Screen, 'useBackBuffer'), Cfg.Screen.useBackBuffer = 1; else end;

%TRIAL EXECUTION SETTINGS USED IN SHOWTRIAL AND POSSIBLY USED IN USER
%DEFINED TRIAL FUNCTION
if ~isfield(Cfg, 'userSuppliedTrialFunction'), Cfg.userSuppliedTrialFunction = []; else end;
if ~isfield(Cfg, 'userDefinedSTMcolumns'), Cfg.userDefinedSTMcolumns = 0; else end;
if ~isfield(Cfg, 'readTextStimuli'), Cfg.readTextStimuli = []; else end;
if ~isfield(Cfg, 'readSoundStimuli'), Cfg.readSoundStimuli = []; else end;
if ~isfield(Cfg, 'responseTerminatesTrial'), Cfg.responseTerminatesTrial = 0; else end;
if ~isfield(Cfg, 'randomizeTrials'), Cfg.randomizeTrials = 0; else end;
if ~isfield(Cfg, 'randomizeTrialsNoImmediateRepeat'), Cfg.randomizeTrialsNoImmediateRepeat = 0; else Cfg.randomizeTrials = 1; end;
if ~isfield(Cfg, 'waitUntilResponseAfterTrial'), Cfg.waitUntilResponseAfterTrial = 0; else end;
if ~isfield(Cfg, 'useTrialOnsetTimes'), Cfg.useTrialOnsetTimes = 0; else end;
if ~isfield(Cfg, 'feedbackTrialCorrect'), Cfg.feedbackTrialCorrect = 0; else Cfg.sndOK = MakeBeep(1000, 0.1);end;
if ~isfield(Cfg, 'feedbackTrialError'), Cfg.feedbackTrialError = 0; else Cfg.sndERR = MakeBeep(500, 0.1);end;
if ~isfield(Cfg, 'onlineFeedback'), Cfg.onlineFeedback = 0; else end; %[{0}|1]
%NOT SURE WETHER THIS WILL STAY
if ~isfield(Cfg, 'task'), Cfg.task = 'default'; else end; %ALTERNATIVES: [ {'DEFAULT'}, 'AUDITORYODDBALL' ]

%RESPONSE DEVICE SETTINGS
if ~isfield(Cfg, 'responseDevice'), Cfg.responseDevice = 'MOUSE'; else end; %[ {'MOUSE'}|'VOICEKEY'|'LUMINAPARALLEL'|'SERIAL'|'KEYBOARD' ]
if ~isfield(Cfg, 'plotVOT'), Cfg.plotVOT = 0; else end;
if ~isfield(Cfg, 'digitalInputDevice'), Cfg.digitalInputDevice = 'NONE'; else end; %[ {'NONE'}|'PARALLEL'|'NIDAQ2' ]
if ~isfield(Cfg, 'digitalOutputDevice'), Cfg.digitalOutputDevice = 'NONE'; else end; %[ {'NONE'}|'PARALLEL'|'NIDAQ2' ]
if ~isfield(Cfg, 'issueTriggers'), Cfg.issueTriggers = 0; else end; %[{0}|1]
if ~isfield(Cfg, 'synchToScanner'), Cfg.synchToScanner = 0; else end; %[{0}|1]
if ~isfield(Cfg, 'synchToScannerPort'), Cfg.synchToScannerPort = 'PARALLEL'; else end; %[{'PARALLEL'}|'SERIAL']
if ~isfield(Cfg, 'timeOutWaitSerial'), Cfg.timeOutWaitSerial = inf; else end; %BY DEFAULT WAIT FOREVER
if ~isfield(Cfg, 'timeOutWaitParallel'), cfg.timeOutWaitParallel = 300; else end;
if ~isfield(Cfg, 'timeOutWaitSerial'), cfg.timeOutWaitSerial = 300; else end;
if ~isfield(Cfg, 'Fs'), Cfg.Fs = 44100; else end;

%EYE TRACKING
if ~isfield(Cfg, 'Eyetracking'), Cfg.Eyetracking = []; else end;
if ~isfield(Cfg.Eyetracking, 'useEyelink'), Cfg.Eyetracking.useEyelink = 0;  else end; %USE EYELINK [ {0}, 1 ]
if ~isfield(Cfg.Eyetracking, 'doDriftCorrection'), Cfg.Eyetracking.doDriftCorrection = 0; else end;
if ~isfield(Cfg.Eyetracking, 'doCalibration'), Cfg.Eyetracking.doCalibration = 0; else end;
if ~isfield(Cfg.Eyetracking, 'edfLargeCalibrationTargets'), Cfg.Eyetracking.edfLargeCalibrationTargets = []; else end; %{[], 1}
if ~isfield(Cfg.Eyetracking, 'useEyelinkMouseMode'), Cfg.Eyetracking.useEyelinkMouseMode = 0; else end; %SIMULATE EYE BY MOUSE useEyelinkMouseMode [ {0}, 1 ]
if ~isfield(Cfg.Eyetracking, 'edfName'), Cfg.Eyetracking.edfName = 'demo.edf'; else end;


function junksub
fprintf(1, 'OG\n')


function [edfFile, el, status, stopkey, startkey, eye_used] = ASF_initEyelinkConnection(useEyelinkMouseMode, windowPtr, edfName)
%function [edfFile, el, status, stopkey, startkey, eye_used] = ASF_initEyelinkConnection(useEyelinkMouseMode, windowPtr, edfName)
% define connection mode and initialize connection as configured in ASF
% Cfg.useEyelink                    = [ {0}, 1 ]    %USE EYELINK
% Cfg.useEyelinkMouseMode           = [ {0}, 1 ]    %SIMULATE EYE BY MOUSE
% created by Angelika Lingnau, 2008-01-26
% edits
%20080707 JS
switch useEyelinkMouseMode
    case 1 %use mouse instead of gaze, initialize dummy connection to the eye tracker
        %mouseInsteadOfGaze=1; %control gaze cursor using mouse instead of gaze (for testing, in case calibration isn't worked out yet)

        status = Eyelink('Initializedummy');
        if (Eyelink('Initializedummy') ~= 0)
            error('could not init connection to Eyelink, status %d', status)
            return;
        end
    case 0 %use gaze position; initialize real connection to the eye tracker
        %mouseInsteadOfGaze=0;
        status = Eyelink('Initialize');
        if (Eyelink('Initialize') ~= 0)
            error('could not init connection to Eyelink, status %d', status)
            return;
        end
end

%timeout=0.85; %stop recording after timeout
%createFile=1; %record eyetracking data on the remote (eyetracking) computer and suck over the file when done
%textOut=1; %write reports from tracker to stdout
edfFile = edfName;

%initialize eyelink default settings
el=EyelinkInitDefaults(windowPtr);
status=Eyelink('command','link_sample_data = LEFT,RIGHT,GAZE,AREA,GAZERES,HREF,PUPIL,STATUS,INPUT');
if status~=0
    error('link_sample_data error, status: %d', status); % make sure that we get gaze data from the Eyelink
end

%open data file if data are recorded
%if createFile
status=Eyelink('openfile',edfFile); % open file to record data to
if status~=0
    error('openfile error, status: %d', status)
end
%end

%do drift correction if gaze data are collected
switch useEyelinkMouseMode
    case 0
        EyelinkDoTrackerSetup(el);
        EyelinkDoDriftCorrect(el);
end

%start recording eye position
status=Eyelink('startrecording'); 
if status~=0
    error('startrecording error, status: %d', status)
end

% record a few samples before we actually start displaying
WaitSecs(0.1); 

% mark zero-plot time in data file
status=Eyelink('message','SYNCTIME'); 
if status~=0
    error('message error, status: %d', status)
end

% initialize keys
stopkey=KbName('space');
%LEFT=KbName('left_mouse');
%RIGHT=KbName('right_mouse');
startkey=KbName('middle_mouse');

%just an initializer to remind us to ask tracker which eye is tracked
eye_used = -1; 
%Priority(priority);
%if doDisplay
%end

%HOW ABOUT ADDING THIS?
% eyelink('command', 'add_file_preamble_text ''Recorded by ASF''');
% 
% %   SET UP TRACKER CONFIGURATION
% eyelink('command', 'calibration_type = HV9');
% %	set parser (conservative saccade thresholds)
% eyelink('command', 'saccade_velocity_threshold = 35');
% eyelink('command', 'saccade_acceleration_threshold = 9500');
% %	set EDF file contents
% eyelink('command', 'file_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,MESSAGE,BUTTON');
% %	set link data (used for gaze cursor)
% eyelink('command', 'link_event_filter = LEFT,RIGHT,FIXATION,BUTTON');
% eyelink('command', 'link_sample_data  = LEFT,RIGHT,GAZE,AREA');
% 
% status=Eyelink('message','EXPERIMENTSTART');
    
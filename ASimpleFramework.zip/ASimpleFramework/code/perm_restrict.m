function temp = perm_restrict(stimvec, nReplications)
%function temp = perm_restrict(stimvec, nReplications)
%permutes stimvec with the restriction that no stimulus will appear twice
%in a row
%each stimulus occurs nReplication times
%
%EXAMPLE CALL:
%stimvec = 1:4;
%nReplications = 2;
%temp = perm_restrict(stimvec, nReplications)


stimvecr = repmat(stimvec, [1, nReplications]);


keep_going = 1;
iteration = 0;
while(keep_going)
    iteration = iteration + 1;
    randvec = randperm(length(stimvecr));

    temp = stimvecr(randvec);

    keep_going = any(diff(temp) == 0);
end

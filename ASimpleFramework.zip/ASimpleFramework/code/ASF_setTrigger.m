%% setTrigger
%function ASF_setTrigger(Cfg, TriggerVal)
function ASF_setTrigger(Cfg, TriggerVal)
if Cfg.issueTriggers
    putvalue(Cfg.hardware.DigitalOutput.mydio.TriggerPort, TriggerVal);
end

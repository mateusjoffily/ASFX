%'PCI-6503'
Cfg.hardware.nidaq.mydio = digitalio('nidaq','Dev2');
% SET THE HIGHEST SPEED POSSIBLE
%set(Cfg.hardware.parallel.mydio, 'TimerPeriod', 0.001)

% 
% PortID Pins         Description
% 0      1            output line (TRIGGER INPUT OF MagPro)
% 1      2            input line  (TRIGGER OUTPUT OF MagPro)

% SET PORT AS AN OUTPUT
addline(Cfg.hardware.nidaq.mydio, 0, 'out', 'TriggerPort')
% % SET PORT AS AN OUTPUT
% addline(Cfg.hardware.nidaq.mydio, 1, 'in', 'ReceiverPort') %SEEMS TO CREATE A PROBLEM

%Cfg.hardware.parallel.ON=0; Cfg.hardware.parallel.OFF=1; %Reverse Logic

Cfg.hardware.nidaq.dioinfos = getvalue(Cfg.hardware.nidaq.mydio)
fprintf(1, 'DONE\n');



%TEST TIMING
% set priority
% priorityLevel = MaxPriority(windowPtr);
% Priority(priorityLevel);

putvalue(Cfg.hardware.nidaq.mydio.TriggerPort, 0)

GetSecs; %loading MEX file
nPulses = 100;
t(nPulses) = 0;
ton(nPulses) = 0;
toff(nPulses) = 0;
timePerCommandMs =1.6268;
waitPeriodS = 0.1 - 2*timePerCommandMs/1000;
for i=1:nPulses
    t(i) = GetSecs;
    putvalue(Cfg.hardware.nidaq.mydio.TriggerPort, 1) %TAKES 1.6150 ms
    ton(i) = GetSecs;
    putvalue(Cfg.hardware.nidaq.mydio.TriggerPort, 0)
    toff(i) = GetSecs;
    WaitSecs(waitPeriodS)
end

figure
subplot(2,1,1)
plot(diff(t)*1000)
subplot(2,1,2)
plot([ ton(:) - t(:), toff(:) - t(:), toff(:) - ton(:)]*1000)
legend('ton - t', 'toff - t', 'toff - ton')

(t(end)-t(1))*1000/(nPulses-1)

tstart = GetSecs;
nPulses = 1000;
for i=1:nPulses
    putvalue(Cfg.hardware.nidaq.mydio.TriggerPort, 1) %TAKES 1.6150 ms
    putvalue(Cfg.hardware.nidaq.mydio.TriggerPort, 0)
end
tend = GetSecs;

timePerCommand = (tend- tstart)/nPulses/2*1000


if exist('daqfind', 'file') == 2
    daqdevices = daqfind;
    if not(isempty(daqdevices))
        for i = length(daqdevices):-1:1
            delete(daqdevices(i));
        end
    end
end



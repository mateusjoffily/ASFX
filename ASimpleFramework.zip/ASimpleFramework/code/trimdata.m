function [tx, nCases] = trimdata(x, pct)
%function [tx, nCases] = trimdata(x, pct)

sx = sort(x(~isnan(x)));
nValues = length(sx(:));

casesLower = 1:(pct/nValues)*100;
casesUpper = sort(nValues - ((1:(pct/nValues)*100) - 1));

startCase = fix(nValues*pct/2/100 + 1);
endCase = ceil(nValues -  nValues*pct/2/100);
nCases = length(startCase:endCase);
tx = sx(startCase:endCase);
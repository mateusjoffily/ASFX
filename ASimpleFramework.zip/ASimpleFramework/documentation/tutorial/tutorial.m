% A Simple Framework (ASF)
% Version 1.0           19 October 2009
% 
% tutorials
% 
% MaskedPriming
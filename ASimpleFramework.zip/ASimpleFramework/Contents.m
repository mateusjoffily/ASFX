% A Simple Framework (ASF)
% Version 1.0           19 October 2009
% 
% tutorials
% 
% Every ASF function has its own documentation available through
% the Matlab HELP command.
% 
%      help ASF       % Triple-click me & hit enter.
%      help ASF_flipX
% 
% ASFdemos             - contains a couple of demos.
% tutorial
%
%
% The folder documentation contains a manual and several ppt shows to
% explain key concepts.
% 